"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENVconfig = void 0;
var dotenv_1 = __importDefault(require("dotenv"));
function getOsEnv(key) {
    if (typeof process.env[key] === 'undefined') {
        throw new Error("\u26A0\uFE0F Environment variable " + key + " is not set .");
    }
    return process.env[key];
}
var envFound = dotenv_1.default.config();
if (envFound.error) {
    // This error should crash whole process
    throw new Error("⚠️ Couldn't find .env file ⚠️ \n" + JSON.stringify(envFound));
}
// Config Objext
exports.ENVconfig = {
    App: {
        name: getOsEnv('APP_NAME'),
        version: '1.0.0',
        host: getOsEnv('APP_HOST'),
    },
    logs: {
        fileslevel: getOsEnv('fileslevel'),
        cloudlevel: getOsEnv('cloudlevel'),
    },
    express: {
        port: parseInt(process.env.PORT || '8080'),
    },
};
