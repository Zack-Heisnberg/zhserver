"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Zh Core Server v1.0.0');
var index_1 = require("./config/index");
var winston_1 = __importDefault(require("winston"));
var logger_1 = require("./loader/logger");
var express_1 = __importDefault(require("./loader/express"));
var loggerchecked = false;
try {
    console.log('Starting Services at ' + new Date().toLocaleString());
    console.log('Config Object is :', index_1.ENVconfig);
    console.log('Booting winston Logger ..');
    logger_1.logger.info('winston Logger Checked');
    loggerchecked = true;
    // Call exceptions.handle with a transport to handle exceptions
    logger_1.logger.exceptions.handle(new winston_1.default.transports.File({ filename: 'exceptions.log' }));
    logger_1.logger.info('Starting Up ExpressJs');
    express_1.default();
    logger_1.logger.info('Starting Up SocketIO');
}
catch (error) {
    if (loggerchecked) {
        logger_1.logger.error(error);
    }
    else {
        console.error(" Error :'( : " + error.message + " ");
    }
}
