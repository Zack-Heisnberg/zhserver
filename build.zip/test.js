// const express = require('express');
// const puppeteer = require('puppeteer-core');
const axios = require('axios');
const AdmZip = require('adm-zip');
const fs = require('fs');
const progress = require('progress-stream');
const rimraf = require('rimraf');
const pb = require('pretty-bytes');
const FormData = require('form-data');
// const app = express();
// const http = require('http').createServer(app);
// const io = require('socket.io')(http);
// const storage = require('node-persist');
const ytdl = require('youtube-dl');
// const { logger } = require('./logger');
const Path = require('path');
// console.log(Path.resolve(__dirname, 'mhtml'));
//rimraf.sync(Path.resolve(__dirname, 'mhtml'));
//fs.mkdirSync('mhtml');

ytdl.getInfo(
  'https://cdn.fbsbx.com/v/t59.2708-21/118750279_754484421796241_515906352211522164_n.mhtml/os3d-e0h1SYMcWojAAAB-page.mhtml?_nc_cat=101&_nc_sid=0cab14&_nc_ohc=Nl1KuIWa5_UAX_22DQS&_nc_ht=cdn.fbsbx.com&oh=1472f72c90fc580a58971141aeaaa071&oe=5F5EC2E7&dl=1&fbclid=IwAR3vK-plrvwW6DGb3fPzOoVNVHGZmPynghfk4oCN9kr2UA2BKkX9YSv6tT0',
  (err, info) => {
    if (err) {
      console.log(err.message);
    } else {
      console.log(info);
    }
  },
);
