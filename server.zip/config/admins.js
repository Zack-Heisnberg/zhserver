module.exports = function (uid) {
  switch (uid) {
    case '8Q12w4wrX5aUYaoAYxVBqAEmVDe2':
      return 'Zakaria'
    default:
      return false
  }
}
