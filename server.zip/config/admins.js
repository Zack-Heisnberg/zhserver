module.exports = function (uid) {
  switch (uid) {
    case '8Q12w4wrX5aUYaoAYxVBqAEmVDe2':
      return 'Zakaria'
    case 'mOINfYA5E2gKDcAHBuHZYRKnIJr1':
      return 'Taki'
    case 'G0nwQWaxrFYfdq6lB6PxgdSqCmr2':
      return 'Islem'
    case 'bjQaxgtrP4Yag9DCBYGXX3DJx9p1':
      return 'Ilyes'
    case '7pQwZzsNCgdhldVX953ZrYZPhOk1':
      return 'Jacob'
    default:
      return false
  }
}
