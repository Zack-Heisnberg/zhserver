const mongoose = require('mongoose')

const activitySchema = new mongoose.Schema({
  uid: { type: String, required: true },
  type: {
    type: String,
    enum: ['Auth', 'Order', 'TopUp'],
  },
  ua: String,
  ip: String,
  description: {
    type: String,
    enum: [
      'SU', //singedip
      'SI', //singin
      'AC',
      'PO', // plavced orded
      'FF', // order FF
      'PF', // order PA
      'NF', // order PA
      'C', // order cancel
      'PT', // placed top
      'TS', // topu acced
      'TR', // topidenm
      'BRR', // Borrow Payment Rejected
      'BRA', // Borrow Payment Accepted
      'PBR', // topup request lend
      'PP', // topup request payment
      'TC', // topup cancled
      'UNS',
    ],
  },
  // Singup singin ac?? -- placedO Osucc Or -- placeto Tssucc top re PLACED brow , PlACED peoo-- notific updare
  params: [String],
  time: { type: Date, default: Date.now },
})
activitySchema.index({ time: -1, uid: 1 })

module.exports = mongoose.model('activity', activitySchema)
