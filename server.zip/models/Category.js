const mongoose = require('mongoose')
const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}
const prices = {
  level: Number,
  qt: [{ q: Number, p: Number, ps: Number }],
}
const variant = {
  name: String,
  prices: [prices],
  needed: Number,
  elreg: [String],
  elregl: Number,
  cur: { type: Number, default: 0 },
  tot: { type: Number, default: 0 },
}
const Category = new mongoose.Schema({
  icon: { type: String, default: 'card_giftcard' },
  title: { type: lang, required: true },
  auid: { type: String, required: true },
  time: { type: Date, default: Date.now },
  category: { type: String },
  image: { type: String },
})
const product = new mongoose.Schema({
  category: { type: String },
  image: { type: String, required: true },
  title: { type: lang, required: true },
  text: { type: lang, required: true },
  types: [variant],
  auid: { type: String, required: true },
  time: { type: Date, default: Date.now },
})
const card = new mongoose.Schema({
  product: { type: String, required: true, index: true },
  type: { type: String, required: true, index: true },
  value: { type: String, index: { unique: true } },
  bnote: { type: String },
  bprice: { type: Number, default: 0 },
  auid: { type: String, required: true },
  time: { type: Date, default: Date.now },
  sold: { type: Boolean, default: false },
  sorder: { type: String, default: 'N/A' },
})
card.index({ product: 1, type: 1, sold: 1 })
const service = new mongoose.Schema({
  category: { type: String },
  image: { type: String, required: true },
  price: { type: String, enum: ['qouata', 'radio'] },
  rprices: [{ name: String, price: Number }],
  title: { type: lang, required: true },
  text: { type: lang, required: true },
  extra: { type: lang, required: true },
  auid: { type: String, required: true },
  time: { type: Date, default: Date.now },
  fields: [String],
})
module.exports = {
  category: mongoose.model('Category', Category),
  product: mongoose.model('product', product),
  card: mongoose.model('cards', card),
  service: mongoose.model('service', service),
}
