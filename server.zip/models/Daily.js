const mongoose = require('mongoose')
const { Schema } = require('mongoose')

const activitySchema = new mongoose.Schema({
  time: Date,
  totorder: { type: Number, min: 0, default: 0 },
  totcard: { type: Number, min: 0, default: 0 },
  toti: { type: Number, min: 0, default: 0 },
  toto: { type: Number, min: 0, default: 0 },
  products: [Schema.Types.Mixed],
  services: [Schema.Types.Mixed],
})

module.exports = mongoose.model('Daily', activitySchema)
