const mongoose = require('mongoose')

const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}

const topupSchema = new mongoose.Schema({
  name: lang,
  min: { type: Number, min: 0 },
  level: { type: Number, unique: true },
  color: { type: String },
})

module.exports = mongoose.model('discount', topupSchema)
