const mongoose = require('mongoose')

const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}

const order = new mongoose.Schema({
  uid: { type: String, required: true },
  status: {
    type: String,
    enum: ['NH', 'NF', 'FF', 'PF', 'C'],
  },
  cards: [{ id: String, value: String }],
  product: { type: String },
  needed: { type: Number },
  handling: { type: Boolean, default: false },
  type: { type: String },
  tdata: {
    typename: String,
    productname: lang,
  },
  qt: { type: Number, min: 0, max: 200 },
  sprice: { q: Number, p: Number, ps: Number },
  time: { type: Date, default: Date.now },
})
order.index({ time: -1, uid: 1, needed: 1, product: 1, type: 1 })

module.exports = mongoose.model('order', order)
