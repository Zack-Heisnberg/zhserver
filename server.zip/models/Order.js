const mongoose = require('mongoose')

const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}

const order = new mongoose.Schema({
  uid: { type: String, required: true },
  status: {
    type: String,
    enum: ['NH', 'NF', 'FF', 'PF', 'C'],
  },
  cards: { type: [{ id: String, value: String }], default: [] },
  product: { type: String },
  handling: { type: Boolean, default: false },
  type: { type: String },
  tdata: {
    typename: String,
    productname: lang,
    productimg: String,
  },
  usedcards: { type: [Number], default: [] },
  qt: { type: Number, min: 0, max: 1000 },
  sprice: { q: Number, p: Number, ps: Number },
  time: { type: Date, default: Date.now },
})
order.index({ time: -1, uid: 1, product: 1, type: 1 })

module.exports = mongoose.model('order', order)
