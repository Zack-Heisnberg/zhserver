const mongoose = require('mongoose')

let admins = {
  Zakaria: { type: Number, default: 0, min: 0 },
}
const lang = {
  en: { type: String, default: '', required: true },
  fr: { type: String, default: '', required: true },
  ar: { type: String, default: '', required: true },
}
const activitySchema = new mongoose.Schema({
  totpt: { type: Number, default: 0, min: 0 },
  totbt: { type: Number, default: 0, min: 0 },
  totct: { type: Number, default: 0, min: 0 },
  totpo: { type: Number, default: 0, min: 0 },
  totps: { type: Number, default: 0, min: 0 },
  Admins: admins,
  Methods: {
    CCP: { type: Number, default: 0, min: 0 },
    Paysera: { type: Number, default: 0, min: 0 },
    Baridimob: { type: Number, default: 0, min: 0 },
    Direct: admins,
  },
  Borrows: {
    CCP: { type: Number, default: 0, min: 0 },
    Paysera: { type: Number, default: 0, min: 0 },
    Baridimob: { type: Number, default: 0, min: 0 },
    Direct: admins,
  },
  lastclear: {
    auid: String,
    time: Date,
  },
  since: { type: Date, default: Date.now },
})

module.exports = mongoose.model('wallet', activitySchema)
