const mongoose = require('mongoose')

const order = new mongoose.Schema({
  uid: { type: String, required: true },
  count: { type: Number, min: 0, default: 0 },
  title: String,
  data: {
    typez: String,
    url: String,
  },
  notification: {
    title: String,
    body: String,
  },
})
order.index({ uid: 1 })

module.exports = mongoose.model('notification', order)
