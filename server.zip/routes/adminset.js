const logger = require('pino')()
const admin = require('firebase-admin')

const mongoose = require('mongoose')
const NewsNotify = require('../utils/newnot')
const ANotify = require('../utils/nota')
const UNotify = require('../utils/notu')
const { Slog, Flog } = require('../models/Logs')
const User = require('../models/User')
const { news, slide } = require('../models/News')
const { category, product, service, card } = require('../models/Category')
const Activity = require('../models/Activity')
const TopUp = require('../models/TopUp')
const Wallet = require('../models/Wallet')
const Method = require('../models/Method')
const Discount = require('../models/Discount')
const { google } = require('googleapis')
const key = require('../config/gdrive.json')
const drive = google.drive('v3')
const jwtClient = new google.auth.JWT(
  key.client_email,
  null,
  key.private_key,
  ['https://www.googleapis.com/auth/drive'],
  null
)
module.exports = async function fb(req, res) {
  Object.keys(req.body).forEach(function (key) {
    if (/\$/g.test(req.body[key])) {
      req.body[key].replace(/\$/g, '\uFF04')
      Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Admin',
        message:
          'Possible Query injection at params ' +
          key +
          ' value ' +
          req.body[key],
      })
    }
    req.alogid.body = JSON.stringify(req.body)
  })
  try {
    if (req.params.name == 'user') {
      if (req.params.settings == 'ban') {
        const payload = JSON.parse(req.body.payload)
        console.log(payload)
        if (payload.flag) {
          await admin.auth().updateUser(payload.uid, {
            disabled: true,
          })
          await User.findOneAndUpdate(
            { uid: payload.uid },
            {
              flaged: true,
              flagenote: payload.note + ' - ' + req.auid + ' - ' + Date.now(),
            }
          )
        } else {
          await admin.auth().updateUser(payload.uid, {
            disabled: false,
          })
          await User.findOneAndUpdate(
            { uid: payload.uid },
            {
              flaged: false,
              flagenote: payload.note + req.auid + '-' + Date.now(),
            }
          )
        }
      } else if (req.params.settings == 'notify') {
        const payload = JSON.parse(req.body.payload)
        UNotify(
          payload.fcmtokens,
          payload.title,
          payload.message,
          'info',
          payload.message,
          'nourl'
        )
      } else {
        throw new Error('404 - admins - user')
      }
      res.json({ done: true })
      return
    }
    if (req.params.name == 'notify') {
      ANotify(
        'Handled',
        'Request id' + req.body.id + ' was handled by ' + req.auid,
        'info',
        req.body.id,
        'nourl'
      )
      res.json({ done: true })
      return
    }
    if (req.params.name == 'topup') {
      const session = await mongoose.connection.startSession()
      session.startTransaction()
      const opts = { session }
      let Atopup = { proof: [] }
      try {
        const id = req.body.id
        const auid = req.auid
        const payload = JSON.parse(req.body.payload)
        if (payload.borrowed) {
          if (payload.accept) {
            const newtopup = {
              status: 'A',
              $push: {
                handle: {
                  auid: auid,
                  payload: req.body.payload,
                  time: Date.now(),
                },
              },
            }
            // topup
            Atopup = await TopUp.findOneAndUpdate(
              { _id: id },
              newtopup,
              opts
            ).lean()
            const newuser = {
              $inc: {
                'userstats.pb': -1,
                'userstats.at': 1,
                'userstats.pba': -parseInt(payload.amount),
                'userstats.tot': parseInt(payload.amount),
              },
            }
            let meth
            let methb
            if (Atopup.method == 'Direct') {
              meth = 'Methods.' + 'Direct.' + req.auid
            } else {
              meth = 'Methods.' + Atopup.method
            }
            if (Atopup.method == 'Direct') {
              methb = 'Borrows.' + 'Direct.' + req.auid
            } else {
              methb = 'Borrows.' + Atopup.method
            }
            const newwallet = {
              $inc: {
                totbt: -1,
                totct: 1,
                [methb]: -Atopup.amount,
                [meth]: Atopup.amount,
              },
            }

            if (Atopup.status !== 'B' && Atopup.status !== 'WAP') {
              throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
            }
            // user
            let user = await User.findOneAndUpdate(
              { uid: Atopup.uid },
              newuser,
              opts
            )
              .lean()
              .select({ fcmtokens: 1 })
            await Activity.create(
              [
                {
                  uid: Atopup.uid,
                  type: 'TopUp',
                  ip: 'ADMIN-IP ' + req.auid,
                  ua: 'ADMIN-UA',
                  description: 'BRA',
                  params: [Atopup._id, Atopup.method, Atopup.amount],
                },
              ],
              session
            )
            // wallet
            await Wallet.updateOne(
              { _id: '123456789012345678901234' },
              newwallet,
              {
                new: true,
                upsert: true, // Make this update into an upsert
              }
            ).session(session)
            UNotify(
              user.fcmtokens,
              'TopUp Accepted',
              'TopUp' + id + ' payment was accepted',
              'positive',
              id,
              '/topup/' + id
            )
            // daily
          } else {
            Atopup = await TopUp.findOneAndUpdate(
              { _id: id },
              {
                status: 'B',
                $push: {
                  handle: {
                    auid: auid,
                    payload: req.body.payload,
                    time: Date.now(),
                  },
                },
              },
              opts
            ).lean()
            if (Atopup.status !== 'B' && Atopup.status !== 'WAP') {
              throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
            }
            // user
            let user = await User.findOne({ uid: Atopup.uid })
              .lean()
              .select({ fcmtokens: 1 })
            await Activity.create(
              [
                {
                  uid: Atopup.uid,
                  type: 'TopUp',
                  ip: 'ADMIN-IP ' + req.auid,
                  ua: 'ADMIN-UA',
                  description: 'BRR',
                  params: [Atopup._id, Atopup.method, Atopup.amount],
                },
              ],
              session
            )
            UNotify(
              user.fcmtokens,
              'TopUp Denied',
              'Sorry, but TopUp ' + id + ' payment was denied :(',
              'negative',
              id,
              '/topup/' + id
            )
          }
          res.json({ done: true })
          await session.commitTransaction()
          session.endSession()
          // rmproof
          if (Atopup.proof.length && payload.rmproof) {
            Atopup.proof.forEach(async (element) => {
              try {
                await drive.files.delete({
                  auth: jwtClient,
                  fileId: element.id,
                })
              } catch (er) {}
            })
          }
          return
        }
        if (payload.accept) {
          const newtopup = {
            status: payload.borrow ? 'B' : 'A',
            borrowed: payload.borrow,
            $push: {
              handle: {
                auid: auid,
                payload: req.body.payload,
                time: Date.now(),
              },
            },
          }
          // topup
          Atopup = await TopUp.findOneAndUpdate(
            { _id: id },
            newtopup,
            opts
          ).lean()
          const newuser = {
            $inc: {
              money: parseInt(payload.amount),
              'userstats.pt': -1,
              [payload.borrow ? 'userstats.pb' : 'userstats.at']: 1,
              [payload.borrow ? 'userstats.pba' : 'userstats.tot']: parseInt(
                payload.amount
              ),
            },
            discount: parseInt(payload.level),
          }
          let meth
          const ttt = payload.borrow ? 'Borrows.' : 'Methods.'
          if (Atopup.method == 'Direct') {
            meth = ttt + 'Direct.' + req.auid
          } else {
            meth = ttt + Atopup.method
          }
          const newwallet = {
            $inc: {
              totpt: -1,
              [payload.borrow ? 'totbt' : 'totct']: 1,
              [meth]: Atopup.amount,
            },
          }

          if (
            Atopup.status !== 'WP' &&
            Atopup.status !== 'WAP' &&
            Atopup.status !== 'WAB'
          ) {
            throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
          }
          // user
          let user = await User.findOneAndUpdate(
            { uid: Atopup.uid },
            newuser,
            opts
          )
            .lean()
            .select({ fcmtokens: 1 })
          await Activity.create(
            [
              {
                uid: Atopup.uid,
                type: 'TopUp',
                ip: 'ADMIN-IP ' + req.auid,
                ua: 'ADMIN-UA',
                description: 'TS',
                params: [Atopup._id, Atopup.method, Atopup.amount],
              },
            ],
            session
          )
          // wallet
          await Wallet.updateOne(
            { _id: '123456789012345678901234' },
            newwallet,
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session)
          UNotify(
            user.fcmtokens,
            'TopUp Accepted',
            'TopUp' + id + ' was accepted :)',
            'positive',
            id,
            '/topup/' + id
          )
          // daily
        } else {
          // topup
          Atopup = await TopUp.findOneAndUpdate(
            { _id: id },
            {
              status: 'D',
              $push: {
                handle: {
                  auid: auid,
                  payload: req.body.payload,
                  time: Date.now(),
                },
              },
            },
            opts
          ).lean()
          if (
            Atopup.status !== 'WP' &&
            Atopup.status !== 'WAP' &&
            Atopup.status !== 'WAB'
          ) {
            throw new Error('AYE AYE AYE DOUBLE HANDLE SHIT')
          }
          // user
          let user = await User.findOneAndUpdate(
            { uid: Atopup.uid },
            { $inc: { 'userstats.pt': -1, 'userstats.dt': 1 } },
            opts
          )
            .lean()
            .select({ fcmtokens: 1 })
          await Activity.create(
            [
              {
                uid: Atopup.uid,
                type: 'TopUp',
                ip: 'ADMIN-IP ' + req.auid,
                ua: 'ADMIN-UA',
                description: 'TR',
                params: [Atopup._id, Atopup.method, Atopup.amount],
              },
            ],
            session
          )
          // wallet
          await Wallet.updateOne(
            { _id: '123456789012345678901234' },
            {
              $inc: { totpt: -1 },
            },
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session)
          UNotify(
            user.fcmtokens,
            'TopUp Denied',
            'Sorry, but topup ' + id + ' was denied',
            'negative',
            id,
            '/topup/' + id
          )
        }
        res.json({ done: true })
        await session.commitTransaction()
        session.endSession()
        // rmproof
        if (Atopup.proof.length && payload.rmproof) {
          Atopup.proof.forEach(async (element) => {
            try {
              await drive.files.delete({
                auth: jwtClient,
                fileId: element.id,
              })
            } catch (er) {}
          })
        }
      } catch (error) {
        await session.abortTransaction()
        session.endSession()
        throw error
      }
      return
    }
    if (req.params.name == 'card') {
      if (req.params.settings == 'create') {
        const payload = JSON.parse(req.body.payload)
        const session = await mongoose.connection.startSession()
        session.startTransaction()
        const opts = { session }
        try {
          let docs = []
          payload.cards.forEach((val) => {
            docs.push({
              auid: req.auid,
              product: payload.product,
              type: payload.type,
              value: payload.type + '**SP**' + val,
              bnote: payload.bnote,
              bprice: payload.bprice,
            })
          })
          let test = await card.insertMany(docs, opts)
          await product
            .updateOne(
              { _id: payload.product },
              {
                $inc: {
                  'types.$[elem].tot': test.length,
                },
              },
              { arrayFilters: [{ 'elem._id': payload.type }] }
            )
            .session(session)
          await session.commitTransaction()
          session.endSession()
          let added = []
          test.forEach((el) => {
            added.push(el.value.split('**SP**')[1])
          })
          res.json({ done: true, added: added })
        } catch (error) {
          await session.abortTransaction()
          session.endSession()
          throw error
        }
      } else if (req.params.settings == 'del') {
        const payload = JSON.parse(req.body.payload)
        const session = await mongoose.connection.startSession()
        session.startTransaction()
        const opts = { session }
        try {
          await card.deleteOne({ _id: req.body.id }, opts)
          await product
            .updateOne(
              { _id: payload.product },
              { $inc: { 'types.$[elem].tot': -1 } },
              { arrayFilters: [{ 'elem._id': payload.type }] }
            )
            .session(session)
          await session.commitTransaction()
          session.endSession()
          res.json({ done: true })
        } catch (error) {
          await session.abortTransaction()
          session.endSession()
          throw error
        }
      } else {
        throw new Error('404 - admins - card')
      }
      return
    }
    let model
    let notify = false
    let image = false
    if (req.params.name == 'news') {
      model = news
      notify = true
    } else if (req.params.name == 'slide') {
      notify = true
      image = true
      model = slide
    } else if (req.params.name == 'product') {
      image = true
      model = product
    } else if (req.params.name == 'service') {
      image = true
      model = service
    } else if (req.params.name == 'category') {
      image = true
      model = category
    } else if (req.params.name == 'cards') {
      image = false
      model = card
    } else if (req.params.name == 'User') {
      model = User
    } else if (req.params.name == 'Activity') {
      model = Activity
    } else if (req.params.name == 'Method') {
      model = Method
    } else if (req.params.name == 'security') {
      model = Slog
    } else if (req.params.name == 'Discount') {
      model = Discount
    } else {
      throw new Error('404 - Bad Model call')
    }
    let body = JSON.parse(req.body.payload)
    body.auid = req.auid
    if (image) {
      // admin uploader
      for (let index = 0; index < req.files.length; index++) {
        await jwtClient.authorize()
        let fileMetadata
        fileMetadata = {
          name:
            req.params.name +
            '-' +
            req.params.settings +
            '-' +
            req.decodedToken.uid,
          parents: ['1SYsmPhitpxd_os1j_U-d72onzMGmZgVx'],
        }
        const media = {
          mimeType: req.files[index].mime,
          body: req.files[index].pass,
        }
        let data = await drive.files.create({
          auth: jwtClient,
          resource: fileMetadata,
          media,
          fields: 'id',
        })
        await drive.permissions.create({
          auth: jwtClient,
          fileId: data.data.id,
          resource: {
            type: 'anyone',
            role: 'reader',
          },
        })
        req.uploaded.push(data.data.id)
        Flog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          name: req.files[0].name,
          filename: req.files[0].filename,
          mime: req.files[0].mime,
          id: data.data.id,
        })
      }
      // admin uploader
    }

    if (req.uploaded.length) {
      body.image =
        'https://drive.google.com/uc?export=view&id=' + req.uploaded[0]
    }
    if (req.params.settings == 'create') {
      await model.create(body)
      if (notify) {
        NewsNotify(body.title, body.text)
      }
    } else if (req.params.settings == 'update') {
      if (req.uploaded.length) {
        let old = await model.findByIdAndUpdate({ _id: req.body.id }, body)
        try {
          await drive.files.delete({
            auth: jwtClient,
            fileId: old.image.split('id=')[1],
          })
        } catch (er) {}
      } else {
        await model.updateOne({ _id: req.body.id }, body)
      }

      if (notify) {
        NewsNotify(body.title, body.text)
      }
    } else if (req.params.settings == 'delete') {
      if (req.params.name == 'product') {
        await card.deleteMany({ product: req.body.id })
      }
      if (image) {
        let old = await model.findByIdAndDelete({ _id: req.body.id })
        try {
          await drive.files.delete({
            auth: jwtClient,
            fileId: old.image.split('id=')[1],
          })
        } catch (er) {}
      } else {
        await model.deleteOne({ _id: req.body.id })
      }
    } else if (req.params.settings == 'security') {
      console.log(body)
      let slog = await model.findByIdAndUpdate(
        { _id: req.body.id },
        {
          handle: {
            ban: body.ban,
            auid: body.auid,
            note: body.note,
            time: Date.now(),
          },
          handled: true,
        }
      )
      if (body.ban) {
        await admin.auth().updateUser(slog.uid, {
          disabled: true,
        })
        await User.findOneAndUpdate(
          { uid: slog.uid },
          {
            flaged: true,
            flagenote: 'Banned due to security ' + req.body.id,
          }
        )
      }
    } else {
      throw new Error('404 - Bad Settings call')
    }
    res.json({
      done: true,
    })
  } catch (err) {
    try {
      if (req.uploaded) {
        req.uploaded.forEach(async (element) => {
          try {
            await drive.files.delete({
              auth: jwtClient,
              fileId: element,
            })
          } catch (er) {}
        })
      }
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Admin',
        message: err.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, ' error not loged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
