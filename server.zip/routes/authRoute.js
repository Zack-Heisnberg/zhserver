// const logger = require('pino')()
const logger = require('pino')()
const { Slog, Flog } = require('../models/Logs')
const User = require('../models/User')
const Activity = require('../models/Activity')

const { google } = require('googleapis')
const key = require('../config/gdrive.json')
const drive = google.drive('v3')
const jwtClient = new google.auth.JWT(
  key.client_email,
  null,
  key.private_key,
  ['https://www.googleapis.com/auth/drive'],
  null
)

module.exports = async function fb(req, res) {
  if (req.body.type == 'csignup') {
    let img = '/avatar.png'
    if (req.files[0]) {
      await jwtClient.authorize()
      let fileMetadata
      if (req.files[0].name == 'avatar') {
        fileMetadata = {
          name: req.decodedToken.uid,
          parents: ['1rf41hMlqMW6Xrno1r5drRfZ11xxLoGGV'],
        }
      } else {
        const slog = new Slog({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'uploadRoute',
          errorobj:
            req.files[0].filename + req.files[0].name + req.files[0].mime,
          message: 'Possible  Request Tamper ',
        })
        await slog.save()
        req.files[0] = null
        return
      }
      const media = {
        mimeType: req.files[0].mime,
        body: req.files[0].pass,
      }
      let data = await drive.files.create({
        auth: jwtClient,
        resource: fileMetadata,
        media,
        fields: 'id',
      })
      await drive.permissions.create({
        auth: jwtClient,
        fileId: data.data.id,
        resource: {
          type: 'anyone',
          role: 'reader',
        },
      })
      let link = await drive.files.get({
        auth: jwtClient,
        fileId: data.data.id,
        fields: 'thumbnailLink',
      })
      if (!link.data.thumbnailLink) {
        const slog = new Slog({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'uploadRoute',
          errorobj:
            req.files[0].filename + req.files[0].name + req.files[0].mime,
          message: 'Possible Bypass - Fileid: ' + data.data.id,
        })
        await slog.save()
      }
      img = 'https://drive.google.com/uc?export=view&id=' + data.data.id
      req.uploaded.push(data.data.id)
      Flog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        name: req.files[0].name,
        filename: req.files[0].filename,
        mime: req.files[0].mime,
        id: data.data.id,
      })
    } else if (req.decodedToken.picture) {
      img = req.decodedToken.picture
    }
    let ident = req.decodedToken.firebase.identities
    const user = new User({
      fullName: req.body.name,
      email: req.decodedToken.email,
      auth: {
        google: ident['google.com'] ? ident['google.com'][0] : null,
        facebook: ident['facebook.com'] ? ident['facebook.com'][0] : null,
      },
      flaged: false,
      image: img,
      phoneNumber: req.decodedToken.phone_number,
      uid: req.decodedToken.uid,
    })
    await user
      .save()
      .then(async () => {
        Activity.create({
          uid: req.decodedToken.uid,
          type: 'Auth',
          ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ua: req.headers['user-agent'],
          description: 'SU',
        })
        res.json({
          done: true,
        })
      })
      .catch(async (err) => {
        req.uploaded.forEach(async (element) => {
          console.log(
            await drive.files.delete({
              auth: jwtClient,
              fileId: element,
            })
          )
        })
        const slog = await Slog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'Auth',
          message: err.message,
        })
        res.json({
          error: true,
          errmsg: 'Error ID: ' + slog._id,
        })
      })
  } else {
    let newimg = false
    if (req.files[0]) {
      await jwtClient.authorize()
      let fileMetadata
      if (req.files[0].name == 'avatar') {
        fileMetadata = {
          name: req.decodedToken.uid,
          parents: ['1rf41hMlqMW6Xrno1r5drRfZ11xxLoGGV'],
        }
      }
      const media = {
        mimeType: req.files[0].mime,
        body: req.files[0].pass,
      }
      let data = await drive.files.create({
        auth: jwtClient,
        resource: fileMetadata,
        media,
        fields: 'id',
      })
      await drive.permissions.create({
        auth: jwtClient,
        fileId: data.data.id,
        resource: {
          type: 'anyone',
          role: 'reader',
        },
      })
      let link = await drive.files.get({
        auth: jwtClient,
        fileId: data.data.id,
        fields: 'thumbnailLink',
      })
      if (!link.data.thumbnailLink) {
        const slog = new Slog({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          type: 'uploadRoute',
          errorobj:
            req.files[0].filename + req.files[0].name + req.files[0].mime,
          message: 'Possible Bypass - Fileid: ' + data.data.id,
        })
        await slog.save()
      }
      newimg = 'https://drive.google.com/uc?export=view&id=' + data.data.id
    }
    const payload = JSON.parse(req.body.payload)
    if (!payload.name) {
      res.json({ error: true, errmsg: 'you need name' })
      return
    }
    let user
    if (newimg) {
      try {
        user = await User.findOneAndUpdate(
          { uid: req.decodedToken.uid },
          {
            fullName: payload.name,
            image: newimg,
          }
        ).lean()
        if (user.image.split('id=')[1]) {
          await drive.files.delete({
            auth: jwtClient,
            fileId: user.image.split('id=')[1],
          })
        }
      } catch (er) {
        logger.error(er)
      }
    } else {
      user = await User.findOneAndUpdate(
        { uid: req.decodedToken.uid },
        {
          fullName: payload.name,
        }
      ).lean()
    }
    user.fullName = payload.name
    if (newimg) {
      user.image = newimg
    }
    res.json({ done: true, user })
  }
}
