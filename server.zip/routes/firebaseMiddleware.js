const admin = require('firebase-admin')
const logger = require('pino')()
const { Alog, Slog } = require('../models/Logs')

const User = require('../models/User')

const mongoose = require('mongoose')
module.exports = async function fb(req, res, next) {
  try {
    if (mongoose.STATES[mongoose.connection.readyState] == 'disconnected') {
      res.json({
        error: true,
        errmsg: 'Our Database is down for now :/',
      })
      return
    }
    const alogdoc = new Alog({
      url: req.protocol + '://' + req.get('host') + req.originalUrl,
      ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
      useragent: req.headers['user-agent'],
      uid: 'N/A',
      method: req.method,
      query: JSON.stringify(req.query),
    })
    req.alogid = alogdoc.toObject()
    await alogdoc.save()
    const { key } = req.headers
    if (!key) {
      throw new Error('No Key Call :/')
    }
    const decodedToken = await admin.auth().verifyIdToken(key)
    alogdoc.uid = decodedToken.uid
    let doc = await User.findOne({ uid: decodedToken.uid }, 'flaged').lean()
    if (doc) {
      if (doc.flaged) {
        res.json({
          error: true,
          errmsg:
            'Error: We Gladly inform you that your account is disabled :/',
        })
        return
      }
    }

    await alogdoc.save()
    req.decodedToken = decodedToken
    next()
  } catch (error) {
    if (req.alogid) {
      const slog = await Slog.create({
        aid: req.alogid,
        type: 'Auth',
        message: error.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } else {
      logger.error(error, 'Auth')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
