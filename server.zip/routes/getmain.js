const logger = require('pino')()
const { Slog } = require('../models/Logs')
const User = require('../models/User')

const notification = require('../models/notification')
const { news, slide } = require('../models/News')
const Activity = require('../models/Activity')
const { category, product, service } = require('../models/Category')
const TopUp = require('../models/TopUp')
const Method = require('../models/Method')
const Discount = require('../models/Discount')
const admin = require('../config/admins')
module.exports = async function fb(req, res) {
  try {
    if (req.params.name == 'notification') {
      if (req.params.settings == 'all') {
        let nots = await notification.find({ uid: req.decodedToken.uid }).lean()
        res.json({ nots })
        await notification.deleteMany({ uid: req.decodedToken.uid })
      }
    } else if (req.params.name == 'user') {
      let duser = await User.findOne({ uid: req.decodedToken.uid }).lean()
      if (duser) {
        if (req.params.settings == 'log') {
          Activity.create({
            uid: req.decodedToken.uid,
            type: 'Auth',
            ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
            ua: req.headers['user-agent'],
            description: 'SI',
          })
        }
        if (req.params.settings == 'adm') {
          Activity.create({
            uid: req.decodedToken.uid,
            type: 'Auth',
            ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
            ua: req.headers['user-agent'],
            description: 'SI',
          })
          if (!admin(req.decodedToken.uid)) {
            await Slog.create({
              aid: req.alogid,
              uid: req.decodedToken.uid,
              type: 'Admin',
              message: 'this dude tried to /admin',
            })
            res.json({
              error: true,
              errmsg: '',
            })
          } else {
            res.json(duser)
          }
        } else {
          res.json(duser)
        }
      } else {
        res.json({
          csingup: true,
        })
      }
    } else if (req.params.name == 'prodmain') {
      if (req.params.settings == 'all') {
        let cats = await category
          .find({}, { icon: 1, title: 1, image: 1, category: 1 })
          .lean()
        let prods = await product
          .find({}, { title: 1, text: 1, image: 1, category: 1 })
          .lean()
        let services = await service
          .find(
            {},
            { title: 1, text: 1, image: 1, category: 1, extra: 1, fields: 1 }
          )
          .lean()
        res.json({ cats, prods, services })
      } else if (req.params.settings == 'prods') {
        let prods = await product.find({}, { title: 1 }).lean()
        res.json({ prods })
      } else {
        let prods = await product
          .findById(req.params.settings, {
            types: 1,
          })
          .lean()
        res.json({ prods })
      }
    } else if (req.params.name == 'news') {
      let dnews = await news.find({}).lean()
      let dslide = await slide.find({}).lean()
      let resp = {
        dnews: [],
        dslides: [],
      }
      if (dnews) {
        resp.dnews = dnews
      }
      if (dslide) {
        resp.dslides = dslide
      }
      res.json(resp)
    } else if (req.params.name == 'activities') {
      const set = req.params.settings.split('-')
      if (set.length !== 4) {
        throw new Error('Bad Req - activities')
      }
      const check = set.every(function (element) {
        return !isNaN(parseInt(element))
      })
      if (!check) {
        throw new Error('Bad Req - Not num - activities')
      }
      const diff = parseInt(set[3]) - parseInt(set[2])
      const daysdiff = diff / 1000 / 60 / 60 / 24
      if (daysdiff > 20) {
        throw new Error('Bad Req - Manipulated req - activities')
      }
      const td = new Date(parseInt(set[3]))
      td.setDate(td.getDate() + 1)
      let to = td.toISOString()
      let from = new Date(parseInt(set[2])).toISOString()
      let count = await Activity.countDocuments({
        time: {
          $gte: from,
          $lte: to,
        },
        uid: req.decodedToken.uid,
      }).lean()
      let resp = await Activity.find({
        time: {
          $gte: from,
          $lte: to,
        },
        uid: req.decodedToken.uid,
      })
        .limit(parseInt(set[1]))
        .skip(parseInt(set[0]))
        .sort({ time: -1 })
        .lean()
      res.json({
        row: resp,
        count: count,
      })
    } else if (req.params.name == 'topup') {
      const set = req.params.settings.split('-')
      if (set.length !== 4) {
        throw new Error('Bad Req - topup')
      }
      const check = set.every(function (element) {
        return !isNaN(parseInt(element))
      })
      if (!check) {
        throw new Error('Bad Req - Not num - topup')
      }
      const diff = parseInt(set[3]) - parseInt(set[2])
      const daysdiff = diff / 1000 / 60 / 60 / 24
      if (daysdiff > 20) {
        throw new Error('Bad Req - Manipulated req - topup')
      }
      const td = new Date(parseInt(set[3]))
      td.setDate(td.getDate() + 1)
      let to = td.toISOString()
      let from = new Date(parseInt(set[2])).toISOString()
      let count = await TopUp.countDocuments({
        time: {
          $gte: from,
          $lte: to,
        },
        uid: req.decodedToken.uid,
      }).lean()
      let resp = await TopUp.find({
        time: {
          $gte: from,
          $lte: to,
        },
        uid: req.decodedToken.uid,
      })
        .limit(parseInt(set[1]))
        .skip(parseInt(set[0]))
        .sort({ time: -1 })
        .lean()
      res.json({
        row: resp,
        count: count,
      })
    } else if (req.params.name == 'methods') {
      let resp = await Method.find().lean()
      if (!resp.length) {
        let defaultmeth = [
          {
            conversion: 1,
            fee: 30,
            enabled: false,
            type: 'Baridimob',
            description: {
              en: '<b>Direct</b> ccp 4564561 , then post',
              fr: '<b>ssss</b> ccp 4564561 , then post',
              ar: 'dqdq',
            },
            __v: 0,
            min: 2000,
            max: 50000,
          },
          {
            conversion: 1,
            fee: 30,
            enabled: true,
            type: 'CCP',
            description: {
              en: '<b>Direct</b> ccp 4564561 , then post',
              fr: '<b>ssss</b> ccp 4564561 , then post',
              ar: 'dqdq',
            },
            __v: 0,
            min: 2000,
            max: 50000,
          },
          {
            conversion: 210,
            fee: 0,
            enabled: true,
            type: 'Paysera',
            min: 20,
            max: 1000,
            description: {
              en: '<b>Direct</b> ccp 4564561 , then post',
              fr: '<b>ssss</b> ccp 4564561 , then post',
              ar: 'dqdq',
            },
            __v: 0,
          },
          {
            conversion: 1,
            fee: 0,
            enabled: true,
            type: 'Direct',
            description: {
              en: '<b>Direct</b> ccp 4564561 , then post',
              fr: '<b>ssss</b> ccp 4564561 , then post',
              ar: 'dqdq',
            },
            __v: 0,
            min: 5000,
            max: 200000,
          },
        ]
        Method.create(defaultmeth)
        resp = defaultmeth
      }
      res.json({
        row: resp,
      })
    } else if (req.params.name == 'discounts') {
      let resp = await Discount.find().lean()
      if (!resp.length) {
        let doc = await Discount.create({
          name: {
            en: 'Bronze',
            fr: 'Bronze',
            ar: 'برونز',
          },
          min: 0,
          level: 0,
          admin: 'Zakaria',
          color: 'brown',
        })
        resp.push(doc.toObject())
      }
      res.json({ resp })
    } else {
      throw new Error('404')
    }
  } catch (err) {
    try {
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Get',
        message: err.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, ' error not loged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
