const express = require('express')
const logger = require('pino')()
const router = express.Router()
const mongoose = require('mongoose')
const { Slog } = require('../models/Logs')
const firebaseMiddleware = require('./firebaseMiddleware')
const adminMiddleware = require('./adminMiddleware')
const uploadMiddleware = require('./uploadMiddleware')
const getmainRoute = require('./getmain')
const getfiltre = require('./getfiltre')
const setmainRoute = require('./setmain')
const adminset = require('./adminset')
const authRoute = require('./authRoute')

router.use('/api', firebaseMiddleware)
router.post('/api/auth', uploadMiddleware)
router.post('/api/auth', authRoute)
router.get('/api/get/:name/:settings', getmainRoute)
router.get('/api/getf/:name/:settings', getfiltre)
router.post('/api/set/:name/:settings', uploadMiddleware)
router.post('/api/set/:name/:settings', setmainRoute)
router.use('/api/admins/:name/:settings', adminMiddleware)
router.post('/api/admins/:name/:settings', uploadMiddleware)
router.post('/api/admins/:name/:settings', adminset)

router.get('/uptime', async (req, res) => {
  res.json({
    dbState: mongoose.STATES[mongoose.connection.readyState],
  })
})
router.use('/api/*', async (req, res) => {
  try {
    const slog = await Slog.create({
      aid: req.alogid,
      uid: req.decodedToken.uid,
      type: '404',
      message: '404 at main',
    })
    res.json({
      error: true,
      errmsg: 'Error ID: ' + slog._id,
    })
  } catch (err) {
    logger.error(err, '404 no loged :( ')
    res.json({
      error: true,
      errmsg: 'Error: Internal Error , Please try again Later',
    })
  }
})
router.get('/*', (req, res) => {
  res.json({
    message: 'ZH ECard Store Server Running ',
  })
})

module.exports = router
