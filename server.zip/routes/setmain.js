const logger = require('pino')()
const { Slog, Flog } = require('../models/Logs')
const User = require('../models/User')
const NotifyAdmins = require('../utils/nota')
const UNotify = require('../utils/notu')
const Activity = require('../models/Activity')
const Daily = require('../models/Daily')
const { product } = require('../models/Category')
const Order = require('../models/Order')
const Wallet = require('../models/Wallet')
const TopUp = require('../models/TopUp')
const fullfill = require('../utils/fullfill')
const admin = require('firebase-admin')
const mongoose = require('mongoose')
const { google } = require('googleapis')
const key = require('../config/gdrive.json')
const drive = google.drive('v3')
const jwtClient = new google.auth.JWT(
  key.client_email,
  null,
  key.private_key,
  ['https://www.googleapis.com/auth/drive'],
  null
)

module.exports = async function fb(req, res) {
  try {
    if (req.params.name == 'notification') {
      if (!req.body.plat || !req.body.lang || !req.body.currentToken) {
        throw new Error('notification bad')
      }
      let duser = await User.findOne({ uid: req.decodedToken.uid })
      if (duser.fcmtokens[req.body.plat]) {
        await admin
          .messaging()
          .unsubscribeFromTopic(duser.fcmtokens[req.body.plat], 'news-en')
        await admin
          .messaging()
          .unsubscribeFromTopic(duser.fcmtokens[req.body.plat], 'news-ar')
        await admin
          .messaging()
          .unsubscribeFromTopic(duser.fcmtokens[req.body.plat], 'news-fr')
      }
      duser.fcmtokens.lang = req.body.lang
      duser.fcmtokens[req.body.plat] = req.body.currentToken
      duser.fcmtokens.account = req.body.data.includes('account')
      duser.fcmtokens.messages = req.body.data.includes('messages')
      duser.fcmtokens.news = req.body.data.includes('news')
      if (req.body.data.includes('news')) {
        await admin
          .messaging()
          .subscribeToTopic(req.body.currentToken, 'news' + '-' + req.body.lang)
      }
      await duser.save()
      Activity.create({
        uid: req.decodedToken.uid,
        type: 'Auth',
        ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ua: req.headers['user-agent'],
        description: 'UNS',
      })
      let tos = duser.toObject()
      res.json({ done: true, duser: tos })
    } else if (req.params.name == 'topup') {
      // uploader
      let proof = []
      for (let index = 0; index < req.files.length; index++) {
        await jwtClient.authorize()
        let fileMetadata
        if (req.files[index].name == 'ident') {
          fileMetadata = {
            name: req.body.id + '-' + req.decodedToken.uid,
            parents: ['1dLt7CNINS0L7hH82WYbTLZ5qgUnCIEnx'],
          }
        } else if (req.files[index].name == 'pv') {
          fileMetadata = {
            name: req.body.id + '-' + req.decodedToken.uid,
            parents: ['1ttRTb_-oyOqyaxKNtIK4Z39663f-qMWI'],
          }
        } else if (req.files[index].name == 'proof') {
          fileMetadata = {
            name: req.body.id + '-' + req.decodedToken.uid,
            parents: ['1cz-zUUNCVPznEbuIkeBMLUzSESAvhYO5'],
          }
        } else {
          throw new Error('Possible  Request Tampe')
        }
        const media = {
          mimeType: req.files[index].mime,
          body: req.files[index].pass,
        }
        let data = await drive.files.create({
          auth: jwtClient,
          resource: fileMetadata,
          media,
          fields: 'id',
        })
        await drive.permissions.create({
          auth: jwtClient,
          fileId: data.data.id,
          resource: {
            type: 'anyone',
            role: 'reader',
          },
        })
        let link = await drive.files.get({
          auth: jwtClient,
          fileId: data.data.id,
          fields: 'thumbnailLink',
        })
        if (!link.data.thumbnailLink) {
          const slog = new Slog({
            aid: req.alogid,
            uid: req.decodedToken.uid,
            type: 'uploadRoute',
            errorobj:
              req.files[0].filename + req.files[0].name + req.files[0].mime,
            message: 'Possible Bypass - Fileid: ' + data.data.id,
          })
          await slog.save()
        }
        proof.push({
          name: req.files[index].name,
          filename: req.files[index].filename,
          thumb: link.data.thumbnailLink,
          id: data.data.id,
        })
        req.uploaded.push(data.data.id)
        Flog.create({
          aid: req.alogid,
          uid: req.decodedToken.uid,
          name: req.files[index].name,
          filename: req.files[index].filename,
          mime: req.files[index].mime,
          id: data.data.id,
        })
      }
      // uploader
      if (req.params.settings == 'new') {
        if (!req.body.method || !req.body.amount) {
          throw new Error('topup bad')
        }
        const session = await mongoose.connection.startSession()
        session.startTransaction()
        const opts = { session }
        try {
          let aTopUp = await TopUp.create(
            [
              {
                uid: req.decodedToken.uid,
                status: 'WP',
                method: req.body.method,
                amount: req.body.amount,
              },
            ],
            opts
          )
          await Wallet.findOneAndUpdate(
            { _id: '123456789012345678901234' },
            {
              $inc: { totpt: 1 },
            },
            {
              new: true,
              upsert: true, // Make this update into an upsert
            }
          ).session(session)
          let user = await User.findOneAndUpdate(
            { uid: req.decodedToken.uid },
            { $inc: { 'userstats.pt': 1 } },
            opts
          )
          await Activity.create(
            [
              {
                uid: req.decodedToken.uid,
                type: 'TopUp',
                ip:
                  req.headers['x-forwarded-for'] ||
                  req.connection.remoteAddress,
                ua: req.headers['user-agent'],
                description: 'PT',
                params: [aTopUp[0]._id, req.body.method, req.body.amount],
              },
            ],
            opts
          )
          res.json({ done: true, TopUp: aTopUp[0].toObject() })
          await session.commitTransaction()
          session.endSession()

          NotifyAdmins(
            'New TopUp Request',
            user.fullName + ' - Id: ' + aTopUp[0]._id,
            'info',
            'ID' + aTopUp[0]._id,
            'nourl'
          )
        } catch (error) {
          await session.abortTransaction()
          session.endSession()
          throw error
        }
      } else if (req.params.settings == 'lend') {
        if (req.files.length < 2 || !req.body.id) {
          throw new Error('bad lend req')
        }
        const session = await mongoose.connection.startSession()
        session.startTransaction()
        let aTopUp
        let user
        try {
          const opts = { session }
          aTopUp = await TopUp.findByIdAndUpdate(
            req.body.id,
            {
              status: 'WAB',
              $push: { proof: proof },
            },
            opts
          )
          if (aTopUp.uid !== req.decodedToken.uid) {
            throw new Error('Useless Attempt to Hijack topup of ' + aTopUp.uid)
          }
          if (aTopUp.status !== 'WP') {
            throw new Error('Attempted to clear proof / or double req ')
          }
          aTopUp.status = 'WAB'
          user = await User.findOne({ uid: req.decodedToken.uid }).session(
            session
          )
          if (user.flagged) {
            throw new Error('User is flagged')
          }
          await Activity.create(
            [
              {
                uid: req.decodedToken.uid,
                type: 'TopUp',
                ip:
                  req.headers['x-forwarded-for'] ||
                  req.connection.remoteAddress,
                ua: req.headers['user-agent'],
                description: 'PBR',
                params: [aTopUp._id, aTopUp.method, aTopUp.amount],
              },
            ],
            session
          )
          await session.commitTransaction()
          session.endSession()
          NotifyAdmins(
            'TopUp Lending Request',
            user.fullName + ' - Id: ' + aTopUp._id,
            'warning',
            'ID' + aTopUp._id,
            '/admin-topup/' + aTopUp._id
          )
          res.json({
            done: true,
            TopUp: aTopUp.toObject(),
            user: user.toObject(),
          })
        } catch (error) {
          // If an error occurred, abort the whole transaction.
          await session.abortTransaction()
          session.endSession()
          throw error
        }
      } else if (req.params.settings == 'proof') {
        if (req.files.length < 1 || !req.body.id) {
          throw new Error('bad lend req')
        }
        const session = await mongoose.connection.startSession()
        session.startTransaction()
        let aTopUp
        let user
        try {
          const opts = { session }
          aTopUp = await TopUp.findByIdAndUpdate(
            req.body.id,
            {
              status: 'WAP',
              $push: { proof: proof },
            },
            opts
          )
          if (aTopUp.uid !== req.decodedToken.uid) {
            throw new Error('Useless Attempt to Hijack topup of ' + aTopUp.uid)
          }
          if (aTopUp.status !== 'WP') {
            if (aTopUp.status !== 'B') {
              throw new Error('Attempted to clear proof / or double req ')
            }
          }
          aTopUp.status = 'WAP'
          user = await User.findOne({ uid: req.decodedToken.uid }).session(
            session
          )
          if (user.flagged) {
            throw new Error('User is flagged')
          }
          await Activity.create(
            [
              {
                uid: req.decodedToken.uid,
                type: 'TopUp',
                ip:
                  req.headers['x-forwarded-for'] ||
                  req.connection.remoteAddress,
                ua: req.headers['user-agent'],
                description: 'PP',
                params: [aTopUp._id, aTopUp.method, aTopUp.amount],
              },
            ],
            session
          )
          await session.commitTransaction()
          session.endSession()
          res.json({
            done: true,
            TopUp: aTopUp.toObject(),
            user: user.toObject(),
          })
          NotifyAdmins(
            'TopUp - Payment Request',
            user.fullName + ' - Id: ' + aTopUp._id,
            'warning',
            'ID' + aTopUp._id,
            '/admin-topup/' + aTopUp._id
          )
        } catch (error) {
          // If an error occurred, abort the whole transaction.
          await session.abortTransaction()
          session.endSession()
          throw error
        }
      } else if (req.params.settings == 'cancel') {
        const session = await mongoose.connection.startSession()
        session.startTransaction()
        let aTopUp
        let user
        await Wallet.updateOne(
          { _id: '123456789012345678901234' },
          {
            $inc: { totpt: -1 },
          },
          {
            new: true,
            upsert: true, // Make this update into an upsert
          }
        ).session(session)
        try {
          const opts = { session }
          aTopUp = await TopUp.findByIdAndUpdate(
            req.body.id,
            {
              status: 'C',
            },
            opts
          )
          if (aTopUp.uid !== req.decodedToken.uid) {
            throw new Error('Useless Attempt to Hijack topup of ' + aTopUp.uid)
          }
          if (aTopUp.borrowed) {
            throw new Error('ATTEMPTED TO CANCEL A BORROW')
          }
          if (
            aTopUp.status == 'A' ||
            aTopUp.status == 'D' ||
            aTopUp.status == 'C' ||
            aTopUp.status == 'B'
          ) {
            throw new Error(
              'Attempted to cancel topup with statue of ' + aTopUp.status
            )
          }
          if (aTopUp.borrowed) {
            throw new Error('Attempted to cancel a borrowed topup !!!!!! ')
          }
          aTopUp.status = 'C'
          user = await User.findOneAndUpdate(
            { uid: req.decodedToken.uid },
            { $inc: { 'userstats.pt': -1, 'userstats.ct': 1 } },
            { session, new: true }
          )
          if (user.flaged) {
            throw new Error('User is flagged')
          }
          Activity.create({
            uid: req.decodedToken.uid,
            type: 'TopUp',
            ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
            ua: req.headers['user-agent'],
            description: 'TC',
            params: [aTopUp._id, aTopUp.method, aTopUp.amount],
          })
          if (aTopUp.proof && aTopUp.proof.length) {
            aTopUp.proof.forEach((element) => {
              drive.files.delete({
                auth: jwtClient,
                fileId: element.id,
              })
            })
          }
          await session.commitTransaction()
          session.endSession()
          res.json({
            done: true,
            TopUp: aTopUp.toObject(),
            user: user.toObject(),
          })
          NotifyAdmins(
            'TopUp Canceled',
            user.fullName + ' - Id: ' + aTopUp._id,
            'info',
            'ID' + aTopUp._id,
            'nourl'
          )
        } catch (error) {
          // If an error occurred, abort the whole transaction.
          await session.abortTransaction()
          session.endSession()
          throw error
        }
      } else {
        throw new Error('404 - TopUp')
      }
    } else if (req.params.name == 'order') {
      const session = await mongoose.connection.startSession()
      session.startTransaction()
      const opts = { session }
      try {
        let user = await User.findOne(
          { uid: req.decodedToken.uid },
          { money: 1, discount: 1 },
          opts
        ).lean()
        let prod = await product
          .findOne(
            { _id: req.body.pid },
            {
              title: 1,
              types: {
                $elemMatch: { _id: req.body.tid },
              },
            },
            opts
          )
          .lean()
        if (!prod) {
          throw new Error('Aye No Product with this ID :/')
        }
        if (!prod.types) {
          throw new Error('Aye No Type with this ID :/')
        }
        // founding Price plan
        let best = 'lala'
        if (prod.types[0].prices) {
          prod.types[0].prices.forEach((element) => {
            if (user.discount === element.level) {
              best = element
            } else {
              if (best == 'lala' && element.level < user.discount) {
                best = element
              }
              if (best < element.level && element.level < user.discount) {
                best = element
              }
            }
          })
          if (best == 'lala') {
            throw new Error('Aye Coudlnt find the best price for this dude :/ ')
          }
          if (!best.qt) {
            throw new Error('Aye there is no qt prices yet ')
          }
        } else {
          throw new Error('Aye No Prices was set for this prod yet')
        }
        // checking if qt is valid
        const n1 = Math.abs(req.body.qt)
        const n2 = parseInt(req.body.qt, 10)
        if (!isNaN(n1) && n2 === n1 && n1.toString() === req.body.qt) {
          req.body.qt = parseInt(req.body.qt)
        } else {
          throw new Error('Aye Not a Natural Number for quantity')
        }
        // founding Price for qt
        let sprice = 0
        best.qt.forEach((element) => {
          if (req.body.qt >= element.q) {
            if (!sprice) {
              sprice = element
            } else if (sprice.p > element.p) {
              sprice = element
            }
          }
        })
        console.log(sprice)
        let amount = parseInt(sprice.p * req.body.qt)
        let ptstd = parseInt(sprice.ps * req.body.qt)
        // alright let get down to buisness
        user = await User.findOneAndUpdate(
          { uid: req.decodedToken.uid },
          {
            $inc: {
              'userstats.totm': amount,
              'userstats.po': 1,
              'userstats.toto': 1,
              money: -amount,
              pts: ptstd,
            },
          },
          opts
        ).lean()
        if (user.money < amount) {
          throw new Error('Aye ya3tih mahna xD , bgha yasra9')
        }
        let aOrder = await Order.create(
          [
            {
              uid: req.decodedToken.uid,
              status: 'NH',
              cards: [],
              product: req.body.pid,
              type: req.body.tid,
              tdata: {
                typename: prod.types[0].name,
                productname: prod.title,
              },
              qt: req.body.qt,
              sprice: sprice,
            },
          ],
          opts
        )
        await Activity.create(
          [
            {
              uid: req.decodedToken.uid,
              type: 'Order',
              ip:
                req.headers['x-forwarded-for'] || req.connection.remoteAddress,
              ua: req.headers['user-agent'],
              description: 'PO',
              params: [
                aOrder[0]._id.toString(),
                req.body.qt,
                prod.title.en,
                prod.types[0].name,
              ],
            },
          ],
          opts
        )
        NotifyAdmins(
          'New Order Placed',
          user.fullName + ' - Id: ' + aOrder[0]._id,
          'info',
          'ID' + aOrder[0]._id,
          'nourl'
        )
        UNotify(
          user.fcmtokens,
          'Order Placed',
          'Order ' + aOrder[0]._id.toString() + ' was Placed',
          'positive',
          aOrder[0]._id.toString(),
          'nourl'
        )
        await session.commitTransaction()
        session.endSession()
        res.json({ done: true, order: aOrder[0] })
        // FULL FILL
        await fullfill(aOrder[0]._id)
        // FULL FILL
      } catch (error) {
        await session.abortTransaction()
        session.endSession()
        throw error
      }
    } else {
      throw new Error('404')
    }
  } catch (err) {
    req.uploaded.forEach(async (element) => {
      await drive.files.delete({
        auth: jwtClient,
        fileId: element,
      })
    })
    try {
      const slog = await Slog.create({
        aid: req.alogid,
        uid: req.decodedToken.uid,
        type: 'Set',
        message: err.message,
      })
      res.json({
        error: true,
        errmsg: 'Error ID: ' + slog._id,
      })
    } catch (err) {
      logger.error(err, ' error not loged ')
      res.json({
        error: true,
        errmsg: 'Error: Internal Error , Please try again Later',
      })
    }
  }
}
