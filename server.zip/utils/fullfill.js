const mongoose = require('mongoose')
const { Slog } = require('../models/Logs')
const logger = require('pino')()
const User = require('../models/User')
const NotifyAdmins = require('../utils/nota')
const UNotify = require('../utils/notu')
const Activity = require('../models/Activity')
const Daily = require('../models/Daily')
const { product, card } = require('../models/Category')
const Order = require('../models/Order')
const Wallet = require('../models/Wallet')
module.exports = async function (id) {
  const session2 = await mongoose.connection.startSession()
  session2.startTransaction()
  const opts2 = { session2 }
  try {
    const aOrder = await Order.findByIdAndUpdate(
      { _id: id },
      { handling: true },
      opts2
    )
    if (!aOrder) {
      throw new Error('No order with this ID')
    }
    if (aOrder.handling) {
      throw new Error('Already being handled')
    }
    if (aOrder.status == 'FF') {
      throw new Error('Already FULLFILLED')
    }
    if (aOrder.status == 'C') {
      throw new Error('CANCLED ORDER')
    }
    if (aOrder.status == 'R') {
      throw new Error('REFUNDED ORDER')
    }
    let cards = []
    if (aOrder.cards) {
      cards = aOrder.cards
    }
    let needed = aOrder.qt
    let ava = true
    let newcards = 0
    let newbuy = 0
    if (cards.length == needed) {
      throw new Error('HEY ITS FULLFILLED')
    }
    console.log(Date.now())
    while (cards.length < needed && ava) {
      let elcardo = await card
        .findOneAndUpdate(
          { product: aOrder.product, type: aOrder.type, sold: false },
          { sold: true, sorder: aOrder._id.toString() },
          { session2, fields: { value: 1, bprice: 1 } }
        )
        .lean()
      if (elcardo) {
        cards.push(elcardo)
        newcards++
        newbuy += elcardo.bprice
      } else {
        ava = false
      }
    }
    console.log(Date.now())
    let newst = ''
    if (cards.length == 0) {
      newst = 'NF'
    } else if (cards.length < needed) {
      newst = 'PF'
    } else if (cards.length == needed) {
      newst = 'FF'
    }

    let trneed = parseInt(needed - cards.length)
    await Order.findByIdAndUpdate(
      { _id: id },
      { handling: false, status: newst, cards: cards, needed: trneed },
      opts2
    ).lean()
    let fforpf
    let num
    if (newst !== 'FF') {
      num = 0
      fforpf = ' Partially Filled'
      await product
        .updateOne(
          { _id: aOrder.product },
          {
            $inc: {
              'types.$[elem].needed': trneed,
              'types.$[elem].cur': newcards,
            },
          },
          { arrayFilters: [{ 'elem._id': aOrder.type }] }
        )
        .session(session2)
      await Wallet.updateOne(
        { _id: '123456789012345678901234' },
        {
          $inc: { totpo: 1 },
        },
        {
          new: true,
          upsert: true, // Make this update into an upsert
        }
      ).session(session2)
      NotifyAdmins(
        'Order Pending ' + aOrder._id,
        aOrder.tdata.productname.en +
          ' - ' +
          aOrder.tdata.typename +
          ' - ' +
          parseInt(needed - newcards),
        'negative',
        aOrder.tdata.productname.en + aOrder._id,
        '/admin-order/' + aOrder._id
      )
    } else {
      num = -1
      fforpf = ' Fullfilled'
      await product
        .updateOne(
          { _id: aOrder.product },
          {
            $inc: {
              'types.$[elem].cur': newcards,
            },
          },
          { arrayFilters: [{ 'elem._id': aOrder.type }] }
        )
        .session(session2)
    }
    let user = await User.findOneAndUpdate(
      { uid: aOrder.uid },
      {
        $inc: {
          'userstats.po': num,
        },
      },
      opts2
    )
    if (cards.length > 0) {
      UNotify(
        user.fcmtokens,
        'Order ' + fforpf,
        'Order ' + aOrder._id.toString() + ' was ' + fforpf,
        'positive',
        aOrder._id.toString(),
        '/order/' + aOrder._id.toString()
      )
    }
    await Activity.create(
      [
        {
          uid: aOrder.uid,
          type: 'Order',
          ip: 'SERVER',
          ua: 'SERVER',
          description: newst,
          params: [
            aOrder._id.toString(),
            needed,
            aOrder.tdata.productname.en,
            aOrder.tdata.typename,
          ],
        },
      ],
      opts2
    )
    await session2.commitTransaction()
    session2.endSession()
  } catch (error) {
    await session2.abortTransaction()
    session2.endSession()
    try {
      await Slog.create({
        type: 'Fullfill',
        message: error.message,
      })
    } catch (err) {
      logger.error(error, ' error not loged ')
    }
  }
}
