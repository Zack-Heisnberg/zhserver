const admin = require('firebase-admin')
const logger = require('pino')()
module.exports = async function (title, body) {
  const message = {
    data: {
      type: 'info',
      url: '/dashboard',
    },
    notification: {
      title: title.en,
      body: body.en,
      tag: 'news',
    },
  }
  const messagefr = {
    data: {
      type: 'info',
      url: '/dashboard',
    },
    notification: {
      title: title.fr,
      body: body.fr,
      tag: 'news',
    },
  }
  const messagear = {
    data: {
      type: 'info',
      url: '/dashboard',
    },
    notification: {
      title: title.ar,
      body: body.ar,
      tag: 'news',
    },
  }
  const options = {
    priority: 'high',
  }

  admin
    .messaging()
    .sendToTopic('news-en', message, options)
    .catch((err) => {
      logger.error(err)
    })
  admin
    .messaging()
    .sendToTopic('news-fr', messagefr, options)
    .catch((err) => {
      logger.error(err)
    })
  admin
    .messaging()
    .sendToTopic('news-ar', messagear, options)
    .then((res) => {
      // console.log(res)
    })
    .catch((err) => {
      logger.error(err)
    })
}
