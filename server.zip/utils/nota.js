const admin = require('firebase-admin')
const logger = require('pino')()
const User = require('../models/User')
module.exports = async function (title, body, type, tag, url) {
  const message = {
    data: {
      type: type,
      url: url,
    },
    notification: {
      title: title,
      body: body,
      tag: tag,
    },
  }
  const options = {
    priority: 'high',
  }
  let tokens = []
  const admins = ['8Q12w4wrX5aUYaoAYxVBqAEmVDe2']
  for (let index = 0; index < admins.length; index++) {
    const uid = admins[index]
    let token = await User.findOne({ uid: uid })
      .select({
        fcmtokens: 1,
        _id: 0,
      })
      .lean()
    switch (type) {
      case 'info':
        if (token.fcmtokens.account) {
          if (token.fcmtokens.pc) {
            tokens.push(token.fcmtokens.pc)
          }
          if (token.mobile) {
            tokens.push(token.fcmtokens.mobile)
          }
        }
        break
      case 'warning':
        if (token.fcmtokens.news) {
          if (token.fcmtokens.pc) {
            tokens.push(token.fcmtokens.pc)
          }
          if (token.mobile) {
            tokens.push(token.fcmtokens.mobile)
          }
        }
        break
      case 'negative':
        if (token.fcmtokens.messages) {
          if (token.fcmtokens.pc) {
            tokens.push(token.fcmtokens.pc)
          }
          if (token.mobile) {
            tokens.push(token.fcmtokens.mobile)
          }
        }
        break
      default:
        break
    }
  }

  if (tokens.length) {
    admin
      .messaging()
      .sendToDevice(tokens, message, options)
      .then((res) => {
        // console.log(res)
      })
      .catch((err) => {
        logger.error(err)
      })
  }
}
