const admin = require('firebase-admin')
const logger = require('pino')()
const User = require('../models/User')
const notification = require('../models/notification')
const axios = require('axios')
const FormData = require('form-data')
module.exports = async function (title, body, type, tag, url) {
  const tag2 = 'st' + tag
  const message = {
    data: {
      type: type,
      url: url,
    },
    notification: {
      title: title,
      body: body,
      tag: tag2,
    },
  }
  const options = {
    priority: 'high',
  }
  let tokens = []
  let psid = []
  const admins = [
    { uid: '8Q12w4wrX5aUYaoAYxVBqAEmVDe2', id: '1843235019128093' },
  ]

  for (let index = 0; index < admins.length; index++) {
    const admin = admins[index]
    let token = await User.findOne({ uid: admin.uid })
      .select({
        fcmtokens: 1,
        _id: 0,
      })
      .lean()
    if (type == 'info' && !token.fcmtokens.account) {
      return
    }
    if (type == 'negative' && !token.fcmtokens.messages) {
      return
    }
    if (type == 'warning' && !token.fcmtokens.news) {
      return
    }
    await notification.updateOne(
      {
        uid: admin.uid,
        title: title,
      },
      {
        data: {
          typez: type,
          url: url,
        },
        notification: {
          title: title,
          body: body,
        },
        $inc: {
          count: 1,
        },
      },
      {
        upsert: true,
        new: true,
      }
    )
    if (admin.id) {
      psid.push(admin.id)
    }
    if (token.fcmtokens.pc) {
      tokens.push(token.fcmtokens.pc)
    }
    if (token.mobile) {
      tokens.push(token.fcmtokens.mobile)
    }
  }

  if (psid.length) {
    psid.forEach((psid) => {
      const messageData = new FormData()
      messageData.append('recipient', '{id:' + psid + '}')
      messageData.append(
        'message',
        '{text: "' +
          title +
          '\\n\\n' +
          body +
          '\\n\\nhttps://tionlinestore.com/#' +
          url +
          '"}'
      )
      axios
        .post(
          'https://graph.facebook.com/v8.0/me/messages?access_token=EAAC5GhaCQU4BAOYqFIfSj5YD8TeiwPXFBCSb7WboEbFB4bMsseuaGZAzu5oTxcZCtAZBYBKmPzZCtyEmurrZAte8T6gH8xVW9Xqfy2g7PeQY4ZCyVrmZAyt64ge1ll7E7cOfhxXU74RKT8Pg5ezG7hhF4SbjfZCU3gZAiHe2GN8tRloTRTJtm5jMD',
          messageData,
          {
            headers: {
              'content-type':
                'multipart/form-data; boundary=' + messageData['_boundary'],
            },
          }
        )
        .then((response) => {
          logger.info(response.data)
        })
        .catch((err) => {
          logger.error(err)
        })
    })
  }
  if (tokens.length) {
    admin
      .messaging()
      .sendToDevice(tokens, message, options)
      .catch((err) => {
        logger.error(err)
      })
  }
}
