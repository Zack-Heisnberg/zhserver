const admin = require('firebase-admin')
const logger = require('pino')()
module.exports = async function (fcmtokens, title, body, type, tag, url) {
  let token = []
  const tag2 = 'st' + tag
  if (fcmtokens.pc) {
    token.push(fcmtokens.pc)
  }
  if (fcmtokens.mobile) {
    token.push(fcmtokens.mobile)
  }
  if (!fcmtokens.account) {
    return
  }
  const message = {
    data: {
      type: type,
      url: url,
    },
    notification: {
      title: title,
      body: body,
      tag: tag2,
    },
  }
  const options = {
    priority: 'high',
  }
  console.log(token)
  if (token.length) {
    await admin
      .messaging()
      .sendToDevice(token, message, options)
      .then((res) => {
        console.log(res.results)
      })
      .catch((err) => {
        logger.error(err)
      })
  }
}
