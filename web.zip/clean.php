<?php



$sess = $_GET['sess'];
$id = $_GET['id'];
$ok = getcwd();
$fulldir = "$ok/downs/$sess-$id/";



unlink("conf/$sess-$id.ini");
exec("rm -rf $fulldir");

$name = $sess.'-'.$id.'.txt';

$files = glob("links2/*-$name"); // get all file names
foreach($files as $file){ // iterate filesj
  if(is_file($file))
 unlink($file); // delete file
}
$name = $sess.'-'.$id.'.html';
$files = glob("links2/*-$name"); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}

$sname = $_COOKIE["sname"];
$waiting = glob("sums/parts/*-$sess-*");

foreach ($waiting as $file) {
unlink($file);
}

if(!empty($_GET['smile'])) {
echo '<meta http-equiv="refresh" content="0; url=index.php?smilar='.$id.'"/>';
} elseif($_COOKIE['multi'] == 1) {
echo '<meta http-equiv="refresh" content="0; url=redir.php"/>';
} else {
echo '<meta http-equiv="refresh" content="0; url=index.php"/>';	
}

?>