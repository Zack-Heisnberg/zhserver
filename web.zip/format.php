<?php

ini_set('max_execution_time', '0');
ini_set('ignore_user_abort', '1');

if ($_COOKIE["zhtube"] !== md5('zakizaki')) {
	die('403');
}


?>

<!DOCTYPE html>
<html>
<head>
  <title>ZH Tube</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://daneden.github.io/animate.css/animate.min.css" />

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


  <style>
.nodec {
text-decoration: none;
display : block;
}

#load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("loading.gif") no-repeat center center rgba(0,0,0,0.25)
}
</style>
</head>
<body class="w3-dark-grey">
<div class="w3-container">
<h2><center class='animated infinite pulse delay-2s slow'><span class='w3-text-green'>Z</span>H <span class='w3-text-red'>T</span>ube</center></h2> <br>
</div>


	<?php
function config_set($config_file, $section, $key, $value) {
    $config_data = parse_ini_file($config_file, true);
    $config_data[$section][$key] = $value;
    $new_content = '';
    foreach ($config_data as $section => $section_content) {
        $section_content = array_map(function($value, $key) {
            return "$key='$value'";
        }, array_values($section_content), array_keys($section_content));
        $section_content = implode("\n", $section_content);
        $new_content .= "[$section]\n$section_content\n";
    }
    file_put_contents($config_file, $new_content);
}




if(!empty($_COOKIE["zhbuff"])) {
$buff = 1024 * 1024 * $_COOKIE["zhbuff"];
} else {
$buff = 1024 * 1024 * 10;
}

$sess = $_COOKIE["sname"].rand(1000, 9999);

if (!empty($_GET['title'])) {
$title = $_GET['title'];
} else {
$title = 'Video';
}

if (!empty($_GET['id'])) {
$url = $_GET['id'];
$id = $_GET['id'];
} else {
$url = $_POST['keyword'];
$rand = md5(rand(9700,1220));
$id = substr($rand,3,9);
}

if(empty($url)) {

echo '<meta http-equiv="refresh" content="0; url=index.php"/>';

  die('no url/id');
}

touch("conf/$sess-$id.ini");
config_set("conf/$sess-$id.ini", "file", "buff", $buff);
config_set("conf/$sess-$id.ini", "file", "title", $title);
config_set("conf/$sess-$id.ini", "file", "url", $url);


if ($_COOKIE['asfile'] == '1') {
config_set("conf/$sess-$id.ini", "file", "asfile", '1');
}



if(empty($_COOKIE["zhtubequal"])) {
setcookie("zhtubequal", 720); 
}
$quality = $_COOKIE["zhtubequal"];


if ( $quality == 'Manual') {

echo '
  <div id="id01" class="w3-modal w3-show">
    <div class="w3-modal-content w3-card-4 w3-text-black">
      <header class="w3-container w3-teal"> 
        <h2>Choose Quality</h2>
      </header>
      <div class="w3-container">
        <table class="w3-table-all w3-hoverable">
    <thead>
      <tr class="w3-red">
        <th>Code</th>
        <th>Resolution</th>
        <th>Size</th>
      </tr>
    </thead>
    ';
// format


$formaton = false;
echo exec("youtube-dl -F '$url' > $sess.txt");
$text = file_get_contents("$sess.txt");
unlink("$sess.txt");

foreach(explode("\n", $text) as $line) {
$line = trim($line);

$formatword = trim(substr($line, 0,6));
// echo $formatword;

if ($formaton == true) {
// echo 'it\'s on'; 
$desc2 = preg_split('/\s+/', $line , 3);
// var_dump($desc2);

if ($desc2['1'] == 'mp4' or $desc2['1'] == 'webm' or $_COOKIE['asfile'] == '1') {
// var_dump($desc2); 

$code = $desc2['0'];
$exten = $desc2['1'];
$ress = explode(',', $desc2['2']);
$size= trim($ress['3']);
$video = substr($size, 0 , 3);
$resolution = trim($ress['0']);
$aud = substr($resolution, 0 , 3);

if(empty($code) or $code == '0') {
  $code = 'file';
}
if ($video !== "vid" && $aud !== "aud" or $_COOKIE['asfile'] == '1') {
echo "
<tr>
      <td><a class='nodec' href='post2.php?id=$id&sess=$sess&code=$code'>
      $code </a></td>
      <td><a class='nodec' href='post2.php?id=$id&sess=$sess&code=$code'> $exten ($resolution) </a></td>
      <td><a class='nodec' href='post2.php?id=$id&sess=$sess&code=$code'> $size </a></td>
    </tr>
"; 
}
}}

if ($formatword == 'format') { 
$formaton = true; 
}
}
// end formats

  echo    '</table></div>
      <footer class="w3-container w3-teal">
        <p>all rights reserver &copy; Zack Heisnberg</p>
      </footer>
    </div>
  </div>';

} else {


config_set("conf/$sess-$id.ini", "file", "quality", "[height <=? $quality]");

$sname = $_COOKIE["sname"];

if($_COOKIE['multi'] == 1) {
echo '<meta http-equiv="refresh" content="0; url=index.php"/>';
touch("waiting/$sess-$id");
} else {
echo '<meta http-equiv="refresh" content="0; url=post2.php?id='.$id.'&sess='.$sess.'"/>';
}


}




?>








</body>
</html>