<?php
ini_set('max_execution_time', '0');
ini_set('ignore_user_abort', '1');

// File - execjob.php START
ob_end_clean();
header("Connection: close");
ignore_user_abort();
ob_start();
echo ('Closing Curl Request');
$size = ob_get_length();
header("Content-Length: $size");
ob_end_flush();
flush();
// BELOW YOUR BACKGROUND JOB/CODE


function config_set($config_file, $section, $key, $value) {
    $config_data = parse_ini_file($config_file, true);
    $config_data[$section][$key] = $value;
    $new_content = '';
    foreach ($config_data as $section => $section_content) {
        $section_content = array_map(function($value, $key) {
            return "$key='$value'";
        }, array_values($section_content), array_keys($section_content));
        $section_content = implode("\n", $section_content);
        $new_content .= "[$section]\n$section_content\n";
    }
    file_put_contents($config_file, $new_content);
}


$sess = $_GET['sess'];
$id = $_GET['id'];
$ok = getcwd();
$fulldir = "$ok/downs/$sess-$id/";

/*
$time = date('j-m-y h:i:s A');
$myfile = fopen("flog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n start\n";
fwrite($myfile, $txt);
fclose($myfile);
*/


if (!is_file("conf/$sess-$id.ini")) {
die();
}


$FILE = fopen("conf/$sess-$id.ini" , 'r');

$config = parse_ini_file("conf/$sess-$id.ini");
$buff = $config['buff'];
$part = $config['upart'];
$cur = $part + 1;
$dur = $config['dur'];
$total = $config['total'];
if(empty($dur)) {
$dur = 0;
}



// add stopper/ checker 

if (empty($total) && is_file("$fulldir/done")) {

if(is_file("$fulldir/$sess-$id.webm")) {
$size = filesize("$fulldir/$sess-$id.webm");
$exten = 'webm';
$total = ceil($size / $buff);
} elseif (is_file("$fulldir/$sess-$id.mp4")) {
$size = filesize("$fulldir/$sess-$id.mp4");
$exten = 'mp4';
$total = ceil($size / $buff);
}
config_set("conf/$sess-$id.ini", "file", "total", $total);
} 

if(is_file("$fulldir/$sess-$id.webm")) {
    $filefull = "$fulldir/$sess-$id.webm";
$size = filesize("$fulldir/$sess-$id.webm");
$exten = 'webm';
$total = ceil($size / $buff);
} elseif (is_file("$fulldir/$sess-$id.mp4")) {
    $filefull = "$fulldir/$sess-$id.mp4";
$size = filesize("$fulldir/$sess-$id.mp4");
$exten = 'mp4';
$total = ceil($size / $buff);
} else {

if(is_file("$fulldir/$sess-$id.webm.part")) {
$filefull = "$fulldir/$sess-$id.webm.part";
$size = filesize("$fulldir/$sess-$id.webm.part");
$exten = 'webm';
$wait = true;
} else {
$filefull = "$fulldir/$sess-$id.mp4.part";
$size = filesize("$fulldir/$sess-$id.mp4.part");
$exten = 'mp4';
$wait = true;
}

// waiter 
$partsize = $part * $buff;
$notyet = $size - $partsize;

if ($notyet > $buff) {
echo 'all good';
} else {
echo 'gona wait';
sleep(3);
// exec("curl 'http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/fuploader.php?sess=$sess&id=$id' 2> /dev/null &");



Echo exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/fuploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");


die();
}
// waiter



}



if (!empty($total) && $cur > $total) {
  unlink($filefull) ; 
 die('done');
}
//end stopper


$splitnum = str_pad($cur, 3, "0", STR_PAD_LEFT);
$outfilename = $splitnum.'-'.$sess.'-'.$id.'.txt.000';
$handle = fopen("$filefull", 'rb') or die("error opening file");
fseek($handle, $dur);
$newdur = $buff + $dur;
$parts = fread($handle,$buff) or die("error reading file");
$handle2 = fopen($outfilename, 'wb') or die("error opening file for writing");
fwrite($handle2,$parts) or die("error writing splited file");     
fclose($handle2) or die("error closing file handle");
$parts = null;

echo $newdur;

// echo " sum $outfilename <br> ";
$nsum = md5_file($outfilename); 
$myfile = fopen("sums/parts/$outfilename", "w") or die("Unable to open file!");
fwrite($myfile, $nsum);
fclose($myfile);

//

$url = "https://graph.facebook.com/v2.6/me/messages?access_token=EAAC5GhaCQU4BAOYqFIfSj5YD8TeiwPXFBCSb7WboEbFB4bMsseuaGZAzu5oTxcZCtAZBYBKmPzZCtyEmurrZAte8T6gH8xVW9Xqfy2g7PeQY4ZCyVrmZAyt64ge1ll7E7cOfhxXU74RKT8Pg5ezG7hhF4SbjfZCU3gZAiHe2GN8tRloTRTJtm5jMD";

$ch = curl_init($url);
//The JSON data.
$jsonData = '{
    "recipient":{
        "id":"1843235019128093"
    }, 
   "message":{
    "attachment":{
      "type":"file", 
      "payload":{
        "is_reusable": true,
        "url":"https://ahoyl7.cfapps.us10.hana.ondemand.com/'.$outfilename.'"
      }
    }
}}';
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($curl, CURLOPT_USERAGENT, $config['useragent']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);

// $result = 'bypass';
// echo "http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/'.$outfilename.'";
// var_dump($result);


$test = json_decode($result, True);
if(!empty($test["message_id"])){
// echo 'Uploaded Success';
unlink($outfilename);
config_set("conf/$sess-$id.ini", "file", "upart", $cur);
config_set("conf/$sess-$id.ini", "file", "dur", $newdur);

// echo 'i should be done';


Echo exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/fuploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");

} else {
// echo "<br>$result<br>";
// echo "<br>Couldn't Upload :(<br>";

$inputr = print_r($result , true);

$myfile = fopen("hlog.txt", "a") or die("Unable to open file!");
$txt = "  I Send \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n $inputr\n";
fwrite($myfile, $txt);
fclose($myfile);

//end log


echo " start of zip <br> ";

rename($outfilename ,"manual/$outfilename");

config_set("conf/$sess-$id.ini", "file", "upart", $cur);
config_set("conf/$sess-$id.ini", "file", "dur", $newdur); 


// curl me

Echo exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/fuploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");



Echo exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/zuploader.php?name=$outfilename' > /dev/null 2>&1 &");









// end zip


}







// end





?>