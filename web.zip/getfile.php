<?php

$sess = $_GET["sess"];
$id = $_GET["id"];
if ($_COOKIE["zhtube"] !== md5('zakizaki')) {
  die('403');
}



?><!DOCTYPE html>
<html>
<head>
  <title><?php echo urldecode($_GET['title']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="w3.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <style>
.nodec {
text-decoration: none;
}

#load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("loading.gif") no-repeat center center rgba(0,0,0,0.25)
}

</style>

<link rel="stylesheet" href="//daneden.github.io/animate.css/animate.min.css" />
<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

</head>
<body class="w3-dark-grey">


<script>
function loading() {



$("#hide").addClass("w3-hide animated zoomOut");
$("#hide").removeClass("w3-show");

$("#load").removeClass("w3-hide");
$("#load").addClass("w3-show animated");


}  

</script>

<div id="load" class='w3-hide'></div>


<div class="w3-container">
<h2><center class='animated infinite pulse delay-2s slow'><span class='w3-text-green'>Z</span>H <span class='w3-text-red'>T</span>ube</center></h2> <br>
</div>

<div id='hide' class='w3-show'>

<div class="w3-cell-row">
  <div class="w3-container w3-cell w3-cell-top">


  </div>
  <div class="w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle">

      
   <h4><center><?php echo substr($_GET['title'], 0 , 45).' ...'; ?>
    
    <br>
    

    <a onclick='loading();' href='http://localhost:8080/clean.php?smile=true&sess=<?php echo $_GET['sess'].'&id='.$_GET['id']; ?>'><i class='fa fa-2x fa-search'></i></a> 

    <a onclick='loading();' href='http://localhost:8080/clean.php?sess=<?php echo $_GET['sess'].'&id='.$_GET['id']; ?>'><i class='nodec fa fa-2x icon-remove'></i></a>

     <a target="_blank" href='http://localhost:8080/opendir.php'><i class='nodec fa fa-2x fa-folder'></i></a>

   <a target="_blank" href='http://localhost:8080/openvid.php?name=<?php echo urldecode($_GET['title']); ?>'><i class='nodec fa fa-2x fa-file'></i></a>

   </center></h4> <br>



<div class="w3-cell-row">

<div id='link' class="w3-hide w3-container w3-cell w3-mobile w3-cell-middle">


<h4> <center> <i class='fa fa-link' style='font-size:24px;color:green'></i> Links Stats: </center> </h4>
<center><div id='ltext'>Started Adding Links </div></center>
<div class="w3-grey w3-border w3-border-color-green w3-round" style="max-width: 300px; margin-right: auto; margin-left: auto;">
<div id='lprogress' class="w3-container w3-round w3-blue" style="width:0%">0%</div>
</div>


</div>

<div id='aria2' class="w3-hide w3-container w3-cell w3-mobile w3-cell-middle">

<h4> <center> <i class='fa fa-download' style='font-size:24px;color:green'></i> <a href='http://localhost:8080/webui/Docs' target="_blank" class='nodec'>Aria2 Stats: </a></center> </h4>
<center>
<ul id='ariacard' class="w3-ul w3-card-4 w3-hide" style="width:100%">
  <li id='speed'>Speed :</li>
  <li id='active'>Active :</li>
  <li id='waiting'>Waiting :</li>
</ul>
<ul id='ariacarderr' class="w3-ul w3-card-4 w3-hide" style="width:100%">
  <li>The Aria Server is Down</li>
</ul>

</center>

</div>

<div id="merger" class="w3-hide w3-container w3-cell w3-mobile w3-cell-middle">

<h4> <center> <i class='fa fa-cog' style='font-size:24px;color:green'></i> Merger Stats: </center> </h4>
<center><div id='mtext'></div></center>
<div class="w3-grey w3-border w3-border-color-green w3-round" style="max-width: 300px; margin-right: auto; margin-left: auto;">
<div id='mprogress' class="w3-container w3-round w3-blue" style="width:0%">0%</div>
</div>



</div>

    </div>


<br>

<div id='stats' class='w3-card w3-padding w3-black w3-border w3-round w3-border-color-red' style="max-width: 300px; margin-right: auto; margin-left: auto;  ">Hold on ..</div>

<br>


<a style="max-width: 300px; margin-right: auto; margin-left: auto;  " id='fix' href="" class="w3-hide w3-btn w3-text-white w3-button  w3-border  w3-border-color-black w3-green">Fix Missing Part</a>

<div id='xhr' style='display : none;'></div>
<div id='xhrdown' style='display : none;'></div>
<div id='xhrupl' style='display : none;'></div>

<script>
var elsta;
var ping;
window.onload = function() {  
elsta = setInterval(stats, 4000); 
stats();  
ping = setInterval(ping, 60000);            
}

var done1 = '0';
var done2 = '0';
var done3 = '0';
var downsta;
var uplsta;
var srclink;
var srcget;
var srcpart;
var partappend;
var added;
var next;
var linkstat;
var ariastat;
var mergerstat;

function ping() {
$.get("links2/index.html", function(data25l){
// alert('data is' + data);
// callme2(data25);
});
}


function stats() {


 $("#xhr").load("manager.php?sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
if (responseTxt == '1' && done1 == '0')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Starting Server Downloader ..");
done1 = '1';
} else if (responseTxt == '2' && done2 == '0')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Downloader Started");
$("#down").removeClass("w3-hide");
$("#down").addClass("animated zoomIn");
downstats();
downsta = setInterval(downstats, 4000);

done2 = '1';
}  else if (responseTxt == '3' && done3 == '0')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Starting Uploader");
$("#upl").removeClass("w3-hide");
$("#down").addClass("animated zoomIn");
uplstats();
uplsta = setInterval(uplstats, 4000);

done3 = '1';
}  else if (responseTxt == '4')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Starting the parts Downloader ..");
$("#link").addClass("animated zoomIn");
$("#link").removeClass("w3-hide");
$("#link").addClass("animated zoomIn");
$("#aria2").addClass("animated zoomIn");
$("#aria2").removeClass("w3-hide");
$("#aria2").addClass("animated zoomIn");

$("#merger").addClass("animated zoomIn");
$("#merger").removeClass("w3-hide");
$("#merger").addClass("animated zoomIn");

clearInterval(elsta);
linkstats();
linkstat = setInterval(linkstats, 4000);
// ariastats();
// ariastat = setInterval(ariastats, 4000);
// mergerstats();
mergerstat = setInterval(mergerstats, 4000);
}
    if(statusTxt == "error")
      alert("Error : " + xhr.status + ": " + xhr.statusText + 'PLease Clean and Try again');
  });
    }






function ariastats() {
  $.get("http://localhost:8080/aria.php", function(dataaria){
// alert('data is' + data);
callme3(dataaria);
});
function callme3(dadaaria) {
if (dadaaria == '-0') {
$("#ariacard").addClass("w3-hide");
$("#ariacarderr").removeClass("w3-hide");
} else {
$("#ariacarderr").addClass("w3-hide");
$("#ariacard").removeClass("w3-hide");
resa = dadaaria.split("-");
$("#speed").text('Speed :' + resa['0']);
$("#active").text('Active :' + resa['1']);
$("#waiting").text('Waiting :' + resa['2']);
}}}


function linkstats() {
  $.get("http://localhost:8080/link.php?sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(datalink, status){
callme2(datalink);
});
function callme2(dadalink) {
res = dadalink.split("-");
if (res['0'] == '0') {
$("#ltext").text('Uploaded ' + res['2'] + '/' + res['3']);
movelink(res['1']);

} else if (res['0'] == '1') {
$("#ltext").text('Uploaded :' + res['2']);

} else if (res['0'] == '2') {
$("#ltext").text('Uploaded ' + res['2'] + '/' + res['3']);
clearInterval(linkstat);
movelink(res['1']);
}

}
}



function mergerstats() {
  $.get("http://localhost:8080/merger.php?sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(datamerg, status){
callme4(datamerg);
});
function callme4(dadamerg) {
resm = dadamerg.split("-");

if (resm['0'] == '1') {
$("#mtext").text(resm['2']);
movem(resm['1']);

} else if (resm['0'] == '2') {
$("#mtext").text(resm['2']);
movem(100);
clearInterval(mergerstat);
clearInterval(ariastat);
$("#stats").text("All Done :)");
<?php
if ($_COOKIE['multi'] == 1) {
echo "window.location.href = 'http://localhost:8080/clean.php?sess=$sess&id=$id';";
}
?>

} else if (resm['0'] == '4') {
$("#mtext").html("<a target='_blank' class='w3-btn w3-red w3-border' href='http://localhost:8080/fix.php?xhr=0&sess=<?php echo $sess;?>&id=<?php echo $id;?>&tomerg="+resm['1']+"'>"+resm['2']+"</a>");
$("#stats").text("Trying To fix missing part.. ");


$.get("http://localhost:8080/fix.php?sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>&xhr=1&tomerg=" + resm['1'], function(responseTxt){
callkk(responseTxt);
 });


}

}
}


function callkk(hhm) {

if(hhm == '101' ){
$("#stats").text("MISSING PART Fixed :) ");
} else {
$("#stats").text("PLEASE FIX Manually MISSING PARTS");
} 
} 
function uplstats() {


$("#upltext").load("manager.php?get=upltext&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>");
$("#xhrupl").load("manager.php?get=uplpercent&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
if (responseTxt == '101') {
responseTxt = '100';
moveupl(responseTxt);
clearInterval(uplsta);
} else {
   moveupl(responseTxt);
}
    if(statusTxt == "error")
      alert("Error : " + xhr.status + ": " + xhr.statusText + 'PLease Clean and Try again');
  });



}

function downstats() {
$("#downtext").load("manager.php?get=downtext&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>");
$("#xhrdown").load("manager.php?get=percent&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
if (responseTxt == '101') {
responseTxt = '100';
   move(responseTxt,'dprogress');
clearInterval(downsta);
} else {
   move(responseTxt,'dprogress');
}
    if(statusTxt == "error")
      alert("Error : " + xhr.status + ": " + xhr.statusText + 'PLease Clean and Try again');
  });



}

var width = 0;
function move(responseTxt,elid) {
  var elem = document.getElementById(elid);   
  var id = setInterval(frame, 10);
  function frame() {
    if (width >= responseTxt) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%';
      elem.innerHTML = width + '%';
    }
  }
}

var uwidth = 0;
function moveupl(responseTxt) {
  var elem = document.getElementById("uprogress");   
  var id = setInterval(frame, 10);
  function frame() {
    if (uwidth >= responseTxt) {
      clearInterval(id);
    } else {
      uwidth++; 
      elem.style.width = uwidth + '%';
      elem.innerHTML = uwidth + '%';
    }
  }
}  

var mwidth = 0;
function movem(responseTxt) {
  var elem = document.getElementById("mprogress");   
  var id = setInterval(frame, 10);
  function frame() {
    if (mwidth >= responseTxt) {
      clearInterval(id);
    } else {
      mwidth++; 
      elem.style.width = mwidth + '%';
      elem.innerHTML = mwidth + '%';
    }
  }
}  

var lwidth = 0;
function movelink(responseTxt) {
  var elem = document.getElementById("lprogress");   
  var id = setInterval(frame, 10);
  function frame() {
    if (lwidth >= responseTxt) {
      clearInterval(id);
    } else {
      lwidth++; 
      elem.style.width = lwidth + '%';
      elem.innerHTML = lwidth + '%';
    }
  }
}  

var width = 0;
function movel(responseTxt) {
  var elem = document.getElementById('lprogress');   
  var id = setInterval(frame, 10);
  function frame() {
    if (width >= responseTxt) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%';
      elem.innerHTML = width + '%';
    }
  }
}     

</script>

  </div>
  <div class="w3-container w3-cell w3-cell-bottom">
  
  </div>
</div>

<br><br>

<div class="w3-cell-row w3-padding">
   <div id='down' class="w3-hide w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-top w3-mobile">

<h4> <center> <i class='fa fa-download' style='font-size:24px;color:green'></i> Download Stats: </center> </h4>

<center> <div id='downtext'></div> </center>

<div class="w3-grey w3-border w3-border-color-green w3-round" style="max-width: 300px; margin-right: auto; margin-left: auto;">
<div id='dprogress' class="w3-container w3-round w3-blue" style="width:0%">0%</div>
</div>

  </div>



  <div id='link' class="w3-hide w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle w3-mobile">
  </div>



  <div id='upl' class="w3-hide w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-bottom w3-mobile">
    
<h4> <center> <i class='fa fa-upload' style='font-size:24px;color:green'></i> Vid Uploading Stats: </center> </h4>
<center><div id='upltext'></div></center>
<div class="w3-grey w3-border w3-border-color-green w3-round" style="max-width: 300px; margin-right: auto; margin-left: auto;">
<div id='uprogress' class="w3-container w3-round w3-blue" style="width:0%">0%</div>
</div>


  </div>
  
</div>


</div>

</body>
</html>