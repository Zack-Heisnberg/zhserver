<?php




if ($_COOKIE["zhtube"] !== md5('zakizaki')) {
  die('403');
}



?><!DOCTYPE html>
<html>
<head>
  <title><?php echo urldecode($_GET['title']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <style>
.nodec {
text-decoration: none;
}

#load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("loading.gif") no-repeat center center rgba(0,0,0,0.25)
}

</style>

<link rel="stylesheet" href="https://daneden.github.io/animate.css/animate.min.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

</head>
<body class="w3-dark-grey">


<script>
function loading() {



$("#hide").addClass("w3-hide animated zoomOut");
$("#hide").removeClass("w3-show");

$("#load").removeClass("w3-hide");
$("#load").addClass("w3-show animated");


}  

</script>

<div id="load" class='w3-hide'></div>


<div class="w3-container">
<h2><center class='animated infinite pulse delay-2s slow'><span class='w3-text-green'>Z</span>H <span class='w3-text-red'>T</span>ube</center></h2> <br>
</div>

<div id='hide' class='w3-show'>

<div class="w3-cell-row">
  <div class="w3-container w3-cell w3-cell-top">
  </div>
  <div class="w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle">

      
   <h4><center><?php echo urldecode($_GET['title']); ?>
    
    <br>
    
    <a target="_blank" href='uploader.php?sess=<?php echo $_GET['sess'].'&id='.$_GET['id']; ?>'><i class='nodec fa fa-2x fa-upload'></i></a>

    <a onclick='loading();' href='clean.php?smile=true&sess=<?php echo $_GET['sess'].'&id='.$_GET['id']; ?>'><i class='fa fa-2x fa-search'></i></a> 

    <a onclick='loading();' href='clean.php?sess=<?php echo $_GET['sess'].'&id='.$_GET['id']; ?>'><i class='nodec fa fa-2x icon-remove'></i></a>


   </center></h4> <br>


   <video id='video'  class="w3-hide" width="100%" controls="">
  <source id='videosrc' src="" type="video/mp4">  
Your browser does not support the video tag That sad :/
</video>


<div id="parts" class="w3-hide w3-card w3-black w3-padding w3-border w3-round w3-border-color-red animated zoomIn" style="max-width: 300px; margin-right: auto; margin-left: auto; overflow-x: scroll; font-size: 20px;">&nbsp;<span class="w3-green w3-round w3-hover-blue-gray w3-padding" onclick="setsrc(1)">Part1</span>&nbsp;</div>

<br>

<div id='stats' class='w3-card w3-padding w3-black w3-border w3-round w3-border-color-red' style="max-width: 300px; margin-right: auto; margin-left: auto;  ">Hold on ..</div>

<div id='xhr' style='display : none;'></div>
<div id='xhrdown' style='display : none;'></div>
<div id='xhrupl' style='display : none;'></div>

<script>
var elsta;
var ping;
window.onload = function() {               
elsta = setInterval(stats, 2000);
stats();  
ping = setInterval(ping, 60000); 
}

var done1 = '0';
var done2 = '0';
var done3 = '0';
var downsta;
var uplsta;
var srclink;
var srcget;
var srcpart;
var partappend;
var added;
var next;


function ping() {
$.get("links2/index.html", function(data25l){
// alert('data is' + data);
// callme2(data25);
});
}

document.getElementById('video').addEventListener('ended',myHandler,false);
    function myHandler(e) {
        // What you want to do after the event
        setsrc(next);

    }


function stats() {


 $("#xhr").load("manager.php?sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
if (responseTxt == '1' && done1 == '0')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Starting Server Downloader ..");
done1 = '1';
} else if (responseTxt == '2' && done2 == '0')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Downloader Started");
$("#down").removeClass("w3-hide");
$("#down").addClass("animated zoomIn");
downsta = setInterval(downstats, 4000);

done2 = '1';
}  else if (responseTxt == '3' && done3 == '0')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Starting Uploader");
$("#upl").removeClass("w3-hide");
$("#down").addClass("animated zoomIn");
uplsta = setInterval(uplstats, 4000);

done3 = '1';
}  else if (responseTxt == '4')  {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Setting the Video Viewer ..");
$("#video").addClass("animated zoomIn");
$("#video").removeClass("w3-hide");
$("#parts").addClass("animated zoomIn");
$("#parts").removeClass("w3-hide");
clearInterval(elsta);
added = 1;
partappend = setInterval(partappend, 6000);
next = (0 + 1 - 1);
setsrc(1);
}
    if(statusTxt == "error")
      alert("Error : " + xhr.status + ": " + xhr.statusText + 'PLease Clean and Try again');
  });
    }


function partappend() {

var text = 'new';
$.get("manager.php?get=parts&sess=<?php echo $_GET['sess'].'&id='.$_GET['id'];?>", function(data22){
// alert('data is' + data);
callme(data22);
});
function callme(parts) {
// alert(parts);
toadd = parts - added;
if (toadd <= 0) {

} else {
for (var i = (added + 1); i <= parts; i++ , added++) {
$("#parts").append('&nbsp;<span class="animated zoomIn w3-green w3-round w3-hover-blue-gray w3-padding" onclick="setsrc('+i+')">Part'+i+'</span>&nbsp;');
}
}


$.get("manager.php?get=total&sess=<?php echo $_GET['sess'].'&id='.$_GET['id'];?>", function(data25){
// alert('data is' + data);
callme2(data25);
});
function callme2(dada) {

  if (dada == added) {
  clearInterval(partappend);  
  }

}

}


}

function setsrc(srcpart) {
srcget = "glink.php?sess=<?php echo $_GET['sess'].'&id='.$_GET['id'];?>&cur=" + srcpart;
$("#stats").addClass("animated zoomIn");
$("#stats").text("Loading Part: " + srcpart);

$.get(srcget, function(data){
  
srclink = data;
if (data == 0) {
$("#stats").addClass("animated zoomIn");
$("#stats").text("Failed Loading Part: " + srcpart);
  } else {
$("#videosrc").attr('src', srclink);
$("#video")[0].load();


var vid = document.getElementById("video");
vid.onloadeddata = function() {

next = 1 + srcpart;
    $("#stats").addClass("animated zoomIn");
$("#stats").text("Loaded Part: " + srcpart);
$("#video")[0].play();
};


}
});

}



function uplstats() {


$("#upltext").load("manager.php?get=upltext&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>");
$("#xhrupl").load("manager.php?get=uplpercent&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
if (responseTxt == '101') {
responseTxt = '100';
moveupl(responseTxt);
clearInterval(uplsta);
} else {
   moveupl(responseTxt);
}
    if(statusTxt == "error")
      alert("Error : " + xhr.status + ": " + xhr.statusText + 'PLease Clean and Try again');
  });



}

function downstats() {
$("#downtext").load("manager.php?get=downtext&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>");
$("#xhrdown").load("manager.php?get=percent&sess=<?php echo $_GET['sess'];?>&id=<?php echo urldecode($_GET['id']); ?>", function(responseTxt, statusTxt, xhr){
    if(statusTxt == "success")
if (responseTxt == '101') {
responseTxt = '100';
   movedown(responseTxt);
clearInterval(downsta);
} else {
   movedown(responseTxt);
}
    if(statusTxt == "error")
      alert("Error : " + xhr.status + ": " + xhr.statusText + 'PLease Clean and Try again');
  });



}

var width = 0;
function movedown(responseTxt) {
  var elem = document.getElementById("progress");   
  var id = setInterval(frame, 10);
  function frame() {
    if (width >= responseTxt) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%';
      elem.innerHTML = width + '%';
    }
  }
}   

var uwidth = 0;
function moveupl(responseTxt) {
  var elem = document.getElementById("uprogress");   
  var id = setInterval(frame, 10);
  function frame() {
    if (uwidth >= responseTxt) {
      clearInterval(id);
    } else {
      uwidth++; 
      elem.style.width = uwidth + '%';
      elem.innerHTML = uwidth + '%';
    }
  }
}   

</script>

  </div>
  <div class="w3-container w3-cell w3-cell-bottom">
  </div>
</div>

<br><br>

<div class="w3-cell-row w3-padding">
   <div id='down' class="w3-hide w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-top w3-mobile">

<h4> <center> <i class='fa fa-download' style='font-size:24px;color:green'></i> Download Stats: </center> </h4>

<center> <div id='downtext'></div> </center>

<div class="w3-grey w3-border w3-border-color-green w3-round" style="max-width: 300px; margin-right: auto; margin-left: auto;">
<div id='progress' class="w3-container w3-round w3-blue" style="width:0%">0%</div>
</div>

  </div>



  <div id='link' class="w3-hide w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle w3-mobile">
  </div>



  <div id='upl' class="w3-hide w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-bottom w3-mobile">
    
<h4> <center> <i class='fa fa-upload' style='font-size:24px;color:green'></i> Vid Uploading Stats: </center> </h4>
<center><div id='upltext'></div></center>
<div class="w3-grey w3-border w3-border-color-green w3-round" style="max-width: 300px; margin-right: auto; margin-left: auto;">
<div id='uprogress' class="w3-container w3-round w3-blue" style="width:0%">0%</div>
</div>


  </div>
  
</div>


</div>

</body>
</html>