<?php

$sess = $_GET['sess'];
$id = $_GET['id'];
$cur = $_GET['cur'];

$cur = str_pad($cur, 3, "0", STR_PAD_LEFT);

$filename = $cur.'-'.$sess.'-'.$id.'.txt';

$cwd = getcwd();

$allfile = "$cwd/links2/$filename";
if(!is_file($allfile)){
 echo "NO";
}else{
 echo trim(file_get_contents($allfile));
}


?>



