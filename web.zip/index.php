<?php

exec("youtube-dl -U");


if (isset($_GET['zackpass']) && $_GET['zackpass'] == 'passzack' ) 
{
setcookie("zhtube",md5('zakizaki'), time() + (10 * 365 * 24 * 60 * 60));  
}

if ($_COOKIE["zhtube"] !== md5('zakizaki')) {
  die('403 Permissions Denied');
}


if(empty($_COOKIE["zhtubequal"])) {
setcookie("zhtubequal", 720); 
}

if (isset($_GET['wait']) ) 
{
$wait = $_GET['wait'];
setcookie("wait", $wait
, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}


if (isset($_GET['quality']) ) 
{
$quality = $_GET['quality'];
setcookie("zhtubequal", $quality
, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}

if (isset($_GET['multi']) ) 
{
$multi = $_GET['multi'];
setcookie("multi", $multi
, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}

if (isset($_GET['sname']) ) 
{
$ssquality = $_GET['sname'];
setcookie("sname", $ssquality
, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}



if (isset($_GET['axel']) ) 
{
$axel = $_GET['axel'];
setcookie("axel", $axel
, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}

if (isset($_GET['buff']) ) 
{
$buff = $_GET['buff'];
setcookie("zhbuff", $buff, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}

if (isset($_GET['asfile']) ) 
{
$asfile = $_GET['asfile'];
setcookie("asfile", $asfile, time() + (10 * 365 * 24 * 60 * 60));  
echo '<meta http-equiv="refresh" content="0,url=index.php">';
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>ZH Tube</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="w3.css">
<link rel="stylesheet" href="//daneden.github.io/animate.css/animate.min.css" />

<script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


  <style>
.nodec {
text-decoration: none;
}

#load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("loading.gif") no-repeat center center rgba(0,0,0,0.25)
}
</style>
</head>
<body class="w3-dark-grey">

<script>
function loading() {



$("#hide").addClass("w3-hide animated zoomOut");
$("#hide").removeClass("w3-show");

$("#load").removeClass("w3-hide");
$("#load").addClass("w3-show animated");


}  

</script>
<div id="load" class='w3-hide'></div>

<div class="w3-container">
<h2><center class='animated infinite pulse delay-2s slow'><span class='w3-text-green'>Z</span>H <span class='w3-text-red'>T</span>ube</center></h2> <br>
</div>

<div id='hide' class='w3-show'>

<div class="w3-cell-row">
  <div class="w3-container w3-cell w3-cell-top">
  </div>
  <div id="searchbox" class="w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle">
    
  <form id="keywordForm" method="post" action="index.php">
    
   <input id='test3' name="keyword" placeholder='Enter video Name or Link' class=" w3-margin-bottom w3-input w3-border w3-round " type="text" required="required" value="<?php
if (!empty($_POST['keyword'])) {
echo $_POST['keyword'];
}

?>" >



<center><input class="w3-btn w3-black w3-col-2 w3-round" type="submit" value="Search" onclick="loading();"> 

<input form="keywordForm" formmethod="post" formaction="format.php" class="w3-btn w3-blue w3-col-2 w3-round" type="submit" value="Direct" onclick="loading();">

</form>


<?php
  if($_COOKIE["asfile"] == '1') {
echo '<a onclick="loading();" href="?asfile=0" class="w3-text-white w3-bar-item w3-button  w3-border  w3-border-color-black w3-green">File</a>';
} else {
echo '<a onclick="loading();" href="?asfile=1" class="w3-text-white w3-bar-item w3-button  w3-border  w3-border-color-black w3-green">Video</a>';
  }  
?>


<br><br>
 

  


  <?php  

  if($_COOKIE["zhtubequal"] == '720') {
    echo '  <a onclick="loading();" href="?quality=480" class="w3-bar-item w3-button  w3-border  w3-border-color-black w3-red w3-text-white">480p</a>
      <a onclick="loading();" href="?quality=720" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-green">720p</a>
      <a onclick="loading();" href="?quality=Manual" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-red">Manual</a> ';
 }   elseif($_COOKIE["zhtubequal"] == '480') {
    echo '  <a onclick="loading();" href="?quality=480" class="w3-text-white w3-bar-item w3-button  w3-border  w3-border-color-black w3-green">480p</a>
      <a onclick="loading();" href="?quality=720" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-red">720p</a>
      <a onclick="loading();" href="?quality=Manual" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-red">Manual</a> ';
 }   else {
    echo '  <a onclick="loading();" href="?quality=480" class="w3-text-white w3-bar-item w3-button  w3-border  w3-border-color-black w3-red">480p</a>
      <a onclick="loading();" href="?quality=720" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-red">720p</a>
      <a onclick="loading();" href="?quality=Manual" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-green">Manual</a> ';

}
      if($_COOKIE["multi"] == '1') {
    echo ' <br>  <br><a onclick="loading();" href="?multi=0" class="w3-text-white w3-bar-item w3-button  w3-border  w3-border-color-black w3-green">Multi</a>
      <a href="redir.php" target="_blank" class="w3-text-white w3-bar-item w3-button w3-border  w3-border-color-black w3-red">Start</a>
     ';
 }   else {
    echo '  <br> <br> <a onclick="loading();" href="?multi=1" class="w3-text-white w3-bar-item w3-button  w3-border  w3-border-color-black w3-black">Multi</a>';
 }

?>

 <br>
  




</center>


  </div>
  <div class="w3-container w3-cell w3-cell-bottom">
  </div>
</div>

<br><br>

<div class="w3-cell-row">
  <div class="w3-container w3-cell w3-cell-top">
  </div>

    


<?php
  define("MAX_RESULTS", 15);
if (isset($_POST['keyword']) or isset($_GET['smilar']) or isset($_GET['next']) )
            {

echo "<div class='animated slideInRight w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle'>";
                $keyword = $_POST['keyword'];
                $smilarid = $_GET['smilar'];
                $next = $_GET['next'];              
              if (!empty($keyword) or !empty($smilarid) or  !empty($next)) 
              {
                $keyword = urlencode($keyword);
                $apikey = 'AIzaSyA-fI5-sgs6bLvujEnzO256USAFlIIPH38';
                
                 if (!empty($next)) {
                $keyword = $_GET['keyword'];     
                $googleApiUrl = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=' . $keyword . '&maxResults=' . MAX_RESULTS . '&type=video&pagetoken='.$next.'&key=' . $apikey;
                }
                elseif (!empty($smilarid)) {
                $googleApiUrl = 'https://www.googleapis.com/youtube/v3/search?part=snippet&relatedToVideoId=' . $smilarid . '&type=video&maxResults=' . MAX_RESULTS . '&key=' . $apikey;
                } elseif (!empty($keyword)) {
                $googleApiUrl = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=' . $keyword . '&maxResults=' . MAX_RESULTS . '&key=' . $apikey;
                }
                $ch = curl_init();

                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_URL, $googleApiUrl);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_VERBOSE, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $response = curl_exec($ch);

                curl_close($ch);
                $data = json_decode($response);
                $value = json_decode(json_encode($data), true);
                for ($i = 0; $i < MAX_RESULTS; $i++) {
                    $videoId = $value['items'][$i]['id']['videoId'];
                    $title = $value['items'][$i]['snippet']['title'];
                    $description = $value['items'][$i]['snippet']['description'];
                    $description = substr($description, 0,250);
                    $tumb = $value['items'][$i]['snippet']['thumbnails']['default']['url'];
      
$dur = file_get_contents("https://www.googleapis.com/youtube/v3/videos?part=contentDetails&type=video&id=$videoId&key=$apikey");

// Echo "https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=$videoId&key=$apikey";

$duration = json_decode($dur, true);

// Var_dump($duration);
$vTime= $duration['items'][0]['contentDetails']['duration'];

$vTime= substr($vTime, 2);


if (!empty($videoId)) {

  $utitle = urlencode($title);


echo "
<table class='animated zoomIn delay-2s slow w3-table w3-hide-small'>
  <tr>
    <td rowspan='2' style='width: 30%;''><center><img style='width: 100%;' src='$tumb'></img></center></th>
    <td><b><a href='format.php?id=$videoId&title=$utitle' onclick='loading();'>$title</a> ($vTime) </b></th>
  </tr>
  <tr>
   <td>$description</td>
  </tr>
</table>
<br>
<table class='w3-table w3-hide-medium w3-hide-large'>
  <tr>
    <th><center><img style='width: 100%;' src='$tumb'></img></center></th>
  </tr>
  <tr>
    <td><b><center><a href='format.php?id=$videoId&title=$utitle' onclick='loading();'>$title</a> ($vTime)</center></b></td>
  </tr>
  <tr>
    <td><center>$description</center></td>
  </tr>
</table>
<br>";
}

// echo $googleApiUrl;
// var_dump($value);

$next = $value["nextPageToken"];

}

echo '
<center><span class="w3-tag w3-padding w3-round-large w3-red w3-center">
<a href="?next='.$next.'&keyword='.$keyword.'" style="text-decoration: none;">More</a><br>
</span></center> </div>

';

}}

 
if ($_COOKIE["multi"] == 1) {

$sname = $_COOKIE["sname"];

$waiting = glob("waiting/$sname*");

echo "<div class='animated slideInRight w3-container w3-light-grey w3-padding w3-border w3-round w3-border-color-blue w3-cell w3-cell-middle'>

<br> <center><h5> Multi List </h5> </center></br>
<ul class='w3-ul w3-card-4'>";
foreach ($waiting as $file) {
$file = substr($file, 8);
$expl = explode('-', $file);
$sess = $expl['0'];
$id = $expl['1'];
// echo $sess.$id;
$config = parse_ini_file("conf/$sess-$id.ini");
$url = $config['url'];
echo "

    <li class='w3-bar'>
      <span onclick='location.href=\"rmfile.php?name=$file\";' class='w3-bar-item w3-button w3-white w3-xlarge w3-right'>×</span>
      <div class='w3-bar-item'>
        <span class='w3-large'>$sess - $id</span><br>
        <span>$url</span>
      </div>
    </li>
  ";
}

echo "</ul></div>";

}




 ?> 
   

 




  
  <div class="w3-container w3-cell w3-cell-bottom">
  </div>
</div>



</body>
</html>