<?php


$quality = $_COOKIE["zhtubequal"];

if(!empty($_COOKIE["zhbuff"])) {
$buff = 1024 * 1024 * $_COOKIE["zhbuff"];
} else {
$buff = 1024 * 1024 * 22;
}


$asfile = $_COOKIE["asfile"];


ini_set('max_execution_time', '0');
ini_set('ignore_user_abort', '1');
function config_set($config_file, $section, $key, $value) {
    $config_data = parse_ini_file($config_file, true);
    $config_data[$section][$key] = $value;
    $new_content = '';
    foreach ($config_data as $section => $section_content) {
        $section_content = array_map(function($value, $key) {
            return "$key='$value'";
        }, array_values($section_content), array_keys($section_content));
        $section_content = implode("\n", $section_content);
        $new_content .= "[$section]\n$section_content\n";
    }
    file_put_contents($config_file, $new_content);
}


$sess = $_GET['sess'];
$id = $_GET['id'];
$ok = getcwd();
$fulldir = "$ok/downs/$sess-$id/";
$config = parse_ini_file("conf/$sess-$id.ini");
$etape = $config['etape'];
$part = $config['upart'];
$name = $config['filename'];


if(!empty($config['total'])){
$total = $config['total'];
}

// the gets 

if (!empty($_GET['get'])) {

if ($_GET['get'] == 'downtext') {
  $s = file_get_contents("$fulldir/out",false, null, -100);
if ($_COOKIE["axel"] == '1')
{

if (preg_match_all('#\bDownloaded (\d+)#', $s, $matches))
 { 
echo "done";
 }
elseif (preg_match_all("/\d+%/", $s, $output_array))
{
$percent = substr($output_array[0][0], 0 , 2); 
preg_match_all('!\d+!', $percent, $percent2);
preg_match_all("/\d+./", $s, $output2);
$speed = $output2[0][0].$output2[0][1]."b/s"; 
// echo $percent;
echo $speed;
}
} else {
$s = explode('[download]',$s);
$last = count($s) - 1;
$lastline = $s[$last];
echo $lastline;
}
}

if ($_GET['get'] == 'upltext') {

  if (!is_file("$fulldir/done")) {
if ($part == '0') {
echo 'Uploader Started ..';
} else {
  echo "Downloader Not Done But Uploaded $part";
}
} else {
if(is_file("$fulldir/$sess-$id.webm")) {
$size = filesize("$fulldir/$sess-$id.webm");
$total = ceil($size / $buff);
} elseif (is_file("$fulldir/$sess-$id.mp4")) {
$size = filesize("$fulldir/$sess-$id.mp4");
$total = ceil($size / $buff);
}
echo "Uploaded $part out of $total";
  }



}

if ($_GET['get'] == 'percent') {
$s = file_get_contents("$fulldir/out",false, null, -100);
if ($_COOKIE["axel"] == '1')
{
if (preg_match_all('#\bDownloaded (\d+)#', $s, $matches) or is_file("$fulldir/done"))
 { 
echo "101";
 }
elseif (preg_match_all("/\d+%/", $s, $output_array))
{
$percent = substr($output_array[0][0], 0 , 2); 
preg_match_all('!\d+!', $percent, $percent2);
preg_match_all("/\d+./", $s, $output2);
$speed = $output2[0][0].$output2[0][1]."b/s"; 

if(is_numeric($percent)){
echo $percent; 
}
// echo $speed;
}
}  else {
$s = explode('[download]',$s);
$last = count($s) - 1;
$lastline = $s[$last];
$divise1 = explode('%',$lastline);
$percent = $divise1[0];
if ($percent == '100' or is_file("$fulldir/done")) {
echo '101';
} else {
echo $percent;
}
}

}

if ($_GET['get'] == 'uplpercent') {

  if (!is_file("$fulldir/done")) {
echo '0';
  } else {
if(is_file("$fulldir/$sess-$id.webm")) {
$size = filesize("$fulldir/$sess-$id.webm");
$total = ceil($size / $buff);
} elseif (is_file("$fulldir/$sess-$id.mp4")) {
$size = filesize("$fulldir/$sess-$id.mp4");
$total = ceil($size / $buff);
}

if ($part == $total) {
  echo '101';
} else {
$percent = round($part / $total, 2);
echo $percent * 100;
}

  }

}


if ($_GET['get'] == 'filename') {
echo $name;
}



if ($_GET['get'] == 'parts') {
echo $part;
}

if ($_GET['get'] == 'total') {
if ($part == $total) {
echo $total;
} else {
  echo '';
}
}

  die();
}


// the gets




// Part 1

if (!is_file("conf/$sess-$id.ini")) {

touch("conf/$sess-$id.ini");
config_set("conf/$sess-$id.ini", "file", "buff", $buff);

$filename = "$ok/downs/$sess-$id/DOWNLOADER";
$dirname = dirname($filename);
if (!is_dir($dirname))
{
    mkdir($dirname, 0777, true);
}
$myfile = fopen("$ok/downs/$sess-$id/DOWNLOADER", 'w') or die("Unable to open file!");
fwrite($myfile,"
echo 'downloading $sess-$id'
echo `date` >> start
youtube-dl -ciw --no-playlist -f '[height <=? $quality]'  '$id' --output '$sess-$id.%(ext)s' > out 2>error
echo `date` >> done
"
);
fclose($myfile);

exec("cd '$ok/downs/$sess-$id/' && tr -d '\r' < 'DOWNLOADER' > 'DOWNLOADERR' && bash DOWNLOADERR  > /dev/null 2>&1 &");

config_set("conf/$sess-$id.ini", "file", "etape", "1");
echo '1';
// end 1
} elseif (is_file("conf/$sess-$id.ini")) {

  


//part2
if ($etape == '1') {

if (is_file("$fulldir/out")) {
$s = file_get_contents("$fulldir/out",false, null, -100);

if ($_COOKIE["axel"] == '1')
{
  
if (preg_match_all('#\bDownloaded (\d+)#', $s, $matches))
 { 
config_set("conf/$sess-$id.ini", "file", "etape", "2");
echo '2';
 }
elseif (preg_match_all("/\d+%/", $s, $output_array))
{
$percent = substr($output_array[0][0], 0 , 2); 
preg_match_all('!\d+!', $percent, $percent2);
preg_match_all("/\d+./", $s, $output2);
$speed = $output2[0][0].$output2[0][1]."b/s"; 
if(is_numeric($percent)){
config_set("conf/$sess-$id.ini", "file", "etape", "2");
echo '2';
} 
// echo $speed;
} elseif (filesize("$fulldir/$sess-$id.mp4.part") > $buff) {
config_set("conf/$sess-$id.ini", "file", "etape", "2");
echo '2';
}

} else {
$s = explode('[download]',$s);
$last = count($s) - 1;
$lastline = $s[$last];
// echo $lastline;
$divise1 = explode('%',$lastline);
$percent = $divise1[0];
if (is_numeric($percent)) {
config_set("conf/$sess-$id.ini", "file", "etape", "2");
echo '2';
}
}}
} 
//end2
// start 3
elseif ($etape == '2') {
config_set("conf/$sess-$id.ini", "file", "upart", "0");

if ($_COOKIE["axel"] == '1')
{

if(!is_file("$fulldir/$sess-$id.webm.part.aria2") and !is_file("$fulldir/$sess-$id.mp4.part.aria2")) {
if($asfile == '1') {
config_set("conf/$sess-$id.ini", "file", "etape", "3");
echo '3';
exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/fuploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");
} else {
config_set("conf/$sess-$id.ini", "file", "etape", "3");
echo '3';
exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");
}

}

} else {

if($_COOKIE["wait"] == '1') {

if(is_file("$fulldir/$sess-$id.mp4") and !is_file("$fulldir/$sess-$id.mp4.part.aria2") and !is_file("$fulldir/$sess-$id.temp.mp4") and is_file("$fulldir/done")) {
if($asfile == '1') {
sleep(20);
config_set("conf/$sess-$id.ini", "file", "etape", "3");
echo '3';
exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/fuploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");
} else {
config_set("conf/$sess-$id.ini", "file", "etape", "3");
echo '3';
exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");
}
}


} else {

if(filesize("$fulldir/$sess-$id.mp4.part") > $buff or filesize("$fulldir/$sess-$id.webm.part") > $buff or is_file("$fulldir/$sess-$id.mp4") or is_file("$fulldir/$sess-$id.webm")) {
if($asfile == '1') {
config_set("conf/$sess-$id.ini", "file", "etape", "3");
echo '3';
exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/fuploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");
} else {
config_set("conf/$sess-$id.ini", "file", "etape", "3");
echo '3';
exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");
}
}

}
}

} 
//end3

elseif ($etape == '3') {

if ($part > 0) {
config_set("conf/$sess-$id.ini", "file", "etape", "4");
echo '4';
} else {

  echo '3';
}



}

// last 4

elseif ($etape == '4') {
echo '4';
}






} 










?>