<?php



$outfilename = $_GET['name'];

echo " Uploading $outfilename <br> ";

$url = "https://graph.facebook.com/v2.6/me/messages?access_token=EAADgkYZCn4ZBABACiH9ic8mgqzH9yLDZBPyoDUCDrsumkJa1syf5hLtZAZCEyLDL8my0tYpQrjsmxVJyoKObCPRF5paNVYZC8cynetMB9JgvDUTtjuP9L3mlJJlFy9B4YVlretk1XGjEeQ4WmS1CrgMWIm46DZCCZBUp5XQbBDFyigZDZD";

$ch = curl_init($url);
//The JSON data.
$jsonData = '{
    "recipient":{
        "id":"1843235019128093"
    }, 
   "message":{
    "attachment":{
      "type":"file", 
      "payload":{
        "is_reusable": true,
        "url":"http://zhtube.ml/manual/'.$outfilename.'"
      }
    }
}}';
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($curl, CURLOPT_USERAGENT, $config['useragent']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);


echo "http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/'.$outfilename.'";
var_dump($result);

