<?php

ini_set('max_execution_time', '0');
ini_set('ignore_user_abort', '1');

$sess = $_GET['sess'];
$id = $_GET['id'];

$config = parse_ini_file("conf/$sess-$id.ini");
$buff = $config['buff'];
$url = $config['url'];
$title = $config['title'];
$asfile = $config['asfile'];

if ($asfile == '1') {
$filename3 = exec("youtube-dl --get-filename  '$url'");
$ext = 'mp4';
$filename2 = substr($filename3, 0 , 200);
config_set("conf/$sess-$id.ini", "file", "filename", $filename2);
} else {
$ext = '%(ext)s';
}

// File - execjob.php START
ob_end_clean();
header("Connection: close");
ignore_user_abort();
ob_start();
if ($asfile == '1') {
echo 'Redirecting .. <meta http-equiv="refresh" content="0; url=getfile.php?id='.$id.'&sess='.$sess.'&title='.$filename2.'"/>';
} else {
echo 'Redirecting ..<meta http-equiv="refresh" content="0; url=getvid.php?id='.$id.'&sess='.$sess.'&title='.$title.'"/>';
}

$time = date('j-m-y h:i:s A');
$myfile = fopen("llog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$url\n $title \n $asfile";
fwrite($myfile, $txt);
fclose($myfile);


$size = ob_get_length();
header("Content-Length: $size");
ob_end_flush();
flush();
// BELOW YOUR BACKGROUND JOB/CODE

function config_set($config_file, $section, $key, $value) {
    $config_data = parse_ini_file($config_file, true);
    $config_data[$section][$key] = $value;
    $new_content = '';
    foreach ($config_data as $section => $section_content) {
        $section_content = array_map(function($value, $key) {
            return "$key='$value'";
        }, array_values($section_content), array_keys($section_content));
        $section_content = implode("\n", $section_content);
        $new_content .= "[$section]\n$section_content\n";
    }
    file_put_contents($config_file, $new_content);
}





if (!empty($_GET['code'])) {
$quality = $_GET['code'];
} else {
$quality = $config['quality'];
}


if($quality == 'file'){
$quality = '0';    
}


if ($_COOKIE["axel"] == '1') {
$cmd = "youtube-dl -ciw --external-downloader aria2c --external-downloader-args '-j 16 -s 16 -x 16 -k 5M' --no-playlist -f '$quality' '$url' --output '$sess-$id.$ext'  > out 2>error";
} else {
$cmd = "youtube-dl -ciw --no-playlist -f '$quality' '$url' --output '$sess-$id.$ext' > out 2>error";
}

$ok = getcwd();
$filename = "$ok/downs/$sess-$id/DOWNLOADER";
$dirname = dirname($filename);
mkdir($dirname, 0777, true);
$myfile = fopen("$ok/downs/$sess-$id/DOWNLOADER", 'w') or die("Unable to open file!");
fwrite($myfile,"
echo 'downloading $sess-$id'
echo `date` >> start
$cmd
echo `date` >> done
"
);

// -f '[height <=? 720]'
fclose($myfile);

config_set("conf/$sess-$id.ini", "file", "etape", "1");






exec("cd '$ok/downs/$sess-$id/' && tr -d '\r' < 'DOWNLOADER' > 'DOWNLOADERR' && bash DOWNLOADERR  > /dev/null 2>&1 &");



?>