<?php


$sname = $_COOKIE["sname"];

$waiting = glob("waiting/$sname*");

$file = $waiting['0'];
$file = substr($file, 8);
$expl = explode('-', $file);
$sess = $expl['0'];
$id = $expl['1'];


unlink("waiting/".$file);
if (!empty($sess)) {

echo '<meta http-equiv="refresh" content="0; url=post2.php?id='.$id.'&sess='.$sess.'"/>';
} else {
echo '<h2><center>Download Done</h2></center>';

}

?>