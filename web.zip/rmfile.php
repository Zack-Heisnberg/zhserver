<?php


$name = $_GET['name'];


unlink("waiting/$name");

unlink("conf/$name.ini");


echo '<meta http-equiv="refresh" content="0; url=index.php"/>';




?>