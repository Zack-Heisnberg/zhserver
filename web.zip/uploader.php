<?php

ini_set('max_execution_time', '0');
ini_set('ignore_user_abort', '1');

// File - execjob.php START
ob_end_clean();
header("Connection: close");
ignore_user_abort();
ob_start();
echo ('Closing Curl Request');
$size = ob_get_length();
header("Content-Length: $size");
ob_end_flush();
flush();
// BELOW YOUR BACKGROUND JOB/CODE

function config_set($config_file, $section, $key, $value) {
    $config_data = parse_ini_file($config_file, true);
    $config_data[$section][$key] = $value;
    $new_content = '';
    foreach ($config_data as $section => $section_content) {
        $section_content = array_map(function($value, $key) {
            return "$key='$value'";
        }, array_values($section_content), array_keys($section_content));
        $section_content = implode("\n", $section_content);
        $new_content .= "[$section]\n$section_content\n";
    }
    file_put_contents($config_file, $new_content);
}


$sess = $_GET['sess'];
$id = $_GET['id'];
$ok = getcwd();
$fulldir = "$ok/downs/$sess-$id/";



/*
$time = date('j-m-y h:i:s A');
$myfile = fopen("flog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n start\n";
fwrite($myfile, $txt);
fclose($myfile);
*/


if (!is_file("conf/$sess-$id.ini")) {
die();

$time = date('j-m-y h:i:s A');
$myfile = fopen("ulog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n dead\n";
fwrite($myfile, $txt);
fclose($myfile);


}


$FILE = fopen("conf/$sess-$id.ini" , 'r');

$config = parse_ini_file("conf/$sess-$id.ini");
$buff = $config['buff'];
$part = $config['upart'];
$cur = $part + 1;
$dur = $config['dur'];
$total = $config['total'];
if(empty($dur)) {
$dur = 0;
}



// add stopper/ checker 

if (empty($total) && is_file("$fulldir/done")) {

if(is_file("$fulldir/$sess-$id.webm")) {
$size = filesize("$fulldir/$sess-$id.webm");
$exten = 'webm';
$total = ceil($size / $buff);
} elseif (is_file("$fulldir/$sess-$id.mp4")) {
$size = filesize("$fulldir/$sess-$id.mp4");
$exten = 'mp4';
$total = ceil($size / $buff);
}
config_set("conf/$sess-$id.ini", "file", "total", $total);

$time = date('j-m-y h:i:s A');
$myfile = fopen("ulog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n total $total set\n";
fwrite($myfile, $txt);
fclose($myfile);


} 

if(is_file("$fulldir/$sess-$id.webm")) {
    $filefull = "$fulldir/$sess-$id.webm";
$size = filesize("$fulldir/$sess-$id.webm");
$exten = 'webm';
$total = ceil($size / $buff);
} elseif (is_file("$fulldir/$sess-$id.mp4")) {
    $filefull = "$fulldir/$sess-$id.mp4";
$size = filesize("$fulldir/$sess-$id.mp4");
$exten = 'mp4';
$total = ceil($size / $buff);
} else {

if(is_file("$fulldir/$sess-$id.webm.part")) {
$filefull = "$fulldir/$sess-$id.webm.part";
$size = filesize("$fulldir/$sess-$id.webm.part");
$exten = 'webm';
$wait = true;
} else {
$filefull = "$fulldir/$sess-$id.mp4.part";
$size = filesize("$fulldir/$sess-$id.mp4.part");
$exten = 'mp4';
$wait = true;
}

// waiter 
$partsize = $part * $buff;
$notyet = $size - $partsize;

if ($notyet > $buff) {
echo 'all good';

$time = date('j-m-y h:i:s A');
$myfile = fopen("ulog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n part all good\n";
fwrite($myfile, $txt);
fclose($myfile);


} else {
echo 'gona wait';
sleep(3);

// exec("curl 'http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/uploader.php?sess=$sess&id=$id' 2> /dev/null &");

/*
$time = date('j-m-y h:i:s A');
$myfile = fopen("flog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n start\n";
fwrite($myfile, $txt);
fclose($myfile);
*/



Exec("wget --spider 'https://zack.cfapps.eu10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");




die();
}
// waiter



}



if (!empty($total) && $cur > $total) {
  unlink($filefull) ; 
 die('done');

 $time = date('j-m-y h:i:s A');
$myfile = fopen("ulog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n done and remove\n";
fwrite($myfile, $txt);
fclose($myfile);

}
//end stopper





$splitnum = str_pad($cur, 3, "0", STR_PAD_LEFT);
$outfilename = $splitnum.'-'.$sess.'-'.$id.'.txt.'.$exten;



exec("ffmpeg -i $filefull -ss $dur -fs $buff -codec copy $outfilename");
$newdur = exec("ffprobe -i $outfilename -show_format -v quiet | sed -n 's/duration=//p'") + $dur;

$newoutfilename = $splitnum.'-'.$sess.'-'.$id.'.txt.000';
rename($outfilename, $newoutfilename);
$outfilename = $newoutfilename;


/*
$time = date('j-m-y h:i:s A');
$myfile = fopen("flog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n start\n";
fwrite($myfile, $txt);
fclose($myfile);
*/




// echo $newdur;

if($newdur < 1) {
sleep(3);

$time = date('j-m-y h:i:s A');
$myfile = fopen("ulog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n new dur is less tehn 1 $newdur \n";
fwrite($myfile, $txt);
fclose($myfile);


Echo exec("wget --spider 'https://zack.cfapps.eu10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");

// exec("curl 'http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/uploader.php?sess=$sess&id=$id' 2> /dev/null &");
die();
}

// echo " Uploading $outfilename <br> ";

$url = "https://graph.facebook.com/v2.6/me/messages?access_token=EAAC5GhaCQU4BAOYqFIfSj5YD8TeiwPXFBCSb7WboEbFB4bMsseuaGZAzu5oTxcZCtAZBYBKmPzZCtyEmurrZAte8T6gH8xVW9Xqfy2g7PeQY4ZCyVrmZAyt64ge1ll7E7cOfhxXU74RKT8Pg5ezG7hhF4SbjfZCU3gZAiHe2GN8tRloTRTJtm5jMD";

$ch = curl_init($url);
//The JSON data.
$jsonData = '{
    "recipient":{
        "id":"1843235019128093"
    }, 
	    "tag": "POST_PURCHASE_UPDATE",
    "messaging_type": "MESSAGE_TAG",
   "message":{
    "attachment":{
      "type":"file", 
      "payload":{
        "is_reusable": true,
        "url":"https://zack.cfapps.eu10.hana.ondemand.com/'.$outfilename.'"
      }
    }
}}';
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($curl, CURLOPT_USERAGENT, $config['useragent']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);


// echo "http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/'.$outfilename.'";
// var_dump($result);



$test = json_decode($result, True);
if(!empty($test["message_id"])){
// echo 'Uploaded Success';
unlink($outfilename);
config_set("conf/$sess-$id.ini", "file", "upart", $cur);
config_set("conf/$sess-$id.ini", "file", "dur", $newdur);

// echo 'i should be done';



Echo exec("wget --spider 'https://zack.cfapps.eu10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");

// exec("curl 'http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/uploader.php?sess=$sess&id=$id' 2> /dev/null &");




} else {
// echo "<br>$result<br>";
// echo "<br>Couldn't Upload :(<br>";

$inputr = print_r($result , true);

$time = date('j-m-y h:i:s A');
$myfile = fopen("ulog.txt", "a") or die("Unable to open file!");
$txt = "  $sess - $id \n $time \n";
fwrite($myfile, $txt);
$txt = "$outfilename \n fail $inputr \n";
fwrite($myfile, $txt);
fclose($myfile);



sleep(3);
// curl me

// exec("curl 'http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/uploader.php?sess=$sess&id=$id' 2> /dev/null &");



Echo exec("wget --spider 'https://zack.cfapps.eu10.hana.ondemand.com/uploader.php?sess=$sess&id=$id' > /dev/null 2>&1 &");



}







// end





?>