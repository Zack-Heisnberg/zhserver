<?php

$path = getcwd().'/links2/';
chmod($path, 0777);



$challenge = $_REQUEST['hub_challenge'];
$verify_token = $_REQUEST['hub_verify_token'];
// Set this Verify Token Value on your Facebook App 
if ($verify_token === 'secretzack') {
  echo $challenge;
}

$inputr = file_get_contents('php://input');


$input = json_decode(file_get_contents('php://input'), true);
// Get the Senders Graph ID
$sender = $input['entry'][0]['messaging'][0]['sender']['id'];
$message = $input['entry'][0]['messaging'][0]['message']['text'];

if ( $sender == "1108441729296518" ) {

$url = $input['entry'][0]['messaging'][0]['message']['attachments'][0]['payload']['url'];

$name = basename($url);
$params = explode('/', $name);
$fileNameFromHeader = $params[count($params) - 1];
$newfname = strtok($fileNameFromHeader, '?');
// $SO = explode('_' , $newfname);
//$name = $SO['0'];

$name = substr($newfname,0 , -8);

unlink('links2/'.$name.'.txt');


$myfile = fopen('links2/'.$name.'.txt', 'a') or die("Unable to open file!");
fwrite($myfile,"
$url
"
);
fclose($myfile);









die();


}


/*
$myfile = fopen("hlog.txt", "a") or die("Unable to open file!");
$txt = "  I Send \n";
fwrite($myfile, $txt);
$txt = "$inputr\n";
fwrite($myfile, $txt);
fclose($myfile);

*/
?>
