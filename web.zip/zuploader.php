<?php

ini_set('max_execution_time', '0');
ini_set('ignore_user_abort', '1');

// File - execjob.php START
ob_end_clean();
header("Connection: close");
ignore_user_abort();
ob_start();
echo ('Closing Curl Request');
$size = ob_get_length();
header("Content-Length: $size");
ob_end_flush();
flush();
// BELOW YOUR BACKGROUND JOB/CODE



$outfilename = $_GET['name'];

if (!is_file("manual/$outfilename")) {
	die();
}
sleep(20);
echo " Uploading $outfilename of zip <br> ";

$url = "https://graph.facebook.com/v2.6/me/messages?access_token=EAADgkYZCn4ZBABAIb3BxnXHTqQQeps10kjs07yBgFk7CB4hNSjMHl2Bc2lj1d4E29H5MRNXa086VQovACAHFz55epZA37oL1hYZAVUZASjFUzFzHVr0pDMINZAVLT457jZBcbbUn8Lij1ukoyK66lMbEqbvwnxTeWR9vdVdLJifi1CZBHVaZBGZBMZApmrYDcWTZB8kZD";

$ch2 = curl_init($url);
//The JSON data.
$jsonData = '{
    "recipient":{
        "id":"1843235019128093"
    }, 
   "message":{
    "attachment":{
      "type":"file", 
      "payload":{
        "is_reusable": true,
        "url":"https://ahoyl7.cfapps.us10.hana.ondemand.com/manual/'.$outfilename.'"
      }
    }
}}';
curl_setopt($ch2, CURLOPT_POST, 1);
curl_setopt($ch2, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch2, CURLOPT_USERAGENT, $config['useragent']);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result2 = curl_exec($ch2);
curl_close($ch2);
//  echo "http://zackfreemobilis-bew.9a6d.starter-us-east-1a.openshiftapps.com/zci/'.$outfilename.'";
var_dump($result2);
$test = json_decode($result2, True);
if(!empty($test["message_id"])){
unlink("manual/$outfilename");


$inputr = print_r($result , true);

$myfile = fopen("zlog.txt", "a") or die("Unable to open file!");
$txt = "  I Send \n";
fwrite($myfile, $txt);
$txt = "$inputr\n on : $outfilename nzf : $notzip";
fwrite($myfile, $txt);
fclose($myfile);


} else {
//rename($outfilename, "manual/$outfilename"); 

Sleep(40);


Echo exec("wget --spider 'https://ahoyl7.cfapps.us10.hana.ondemand.com/zuploader.php?name=$outfilename' > /dev/null 2>&1 &");

$inputr = print_r($result , true);

$myfile = fopen("zlog.txt", "a") or die("Unable to open file!");
$txt = "  I Send \n";
fwrite($myfile, $txt);
$txt = "$inputr\n on : $outfilename nzf : $notzipFile";
fwrite($myfile, $txt);
fclose($myfile);
}
?>